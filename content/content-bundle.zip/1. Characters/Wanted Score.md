## Wanted Scores 

In the course of adventuring far and wide, a character (or entire party) can sometimes end up on the wrong side of the law and public opinion. A Wanted Score allows a Dungeon Master to track how characters are perceived by rulers, law enforcement, and citizens of a particular area, region, or nation. This score comes with an attendant status that gives further guidance on how the world reacts to a character’s presence based on their past actions. 

Like Hit Points, a Wanted Score is an abstract way for the DM to see where things stand at a glance. Increases and decreases to a character’s Wanted Score are declared by the DM. The score should not be increased for every minor infraction and it should not be decreased by every heroic deed.  

Lines between one score and the next are soft, meaning the DM should make a judgment call as to whether or not a certain incident should increase the Wanted Score, especially if this grants a new status. 

You can reduce your wanted score within the descriptions below or;
1. [[Paying to reduce wanted score]] via [[the Black Market]]
2. [[Bigger Fish]]
3. [[Connections]]

Resisting arrest and/or breaking out of prison increases a character’s Wanted Score by 1 (max 6). (If/when noticed - roll group deception check once per day. If [[Enemy of the state]] roll with [[Disadvantage]]. [[Enemy of the plane]] will automatically be noticed not being there if allowed to live)


The [[Public Perception]] and [[Law Enforcement]] have descriptions addressed to players to help them understand their status. 

| Score | Distance     | Status             | Impact    |
| ----- | ------------ | ------------------ | --- |
| 1     | [[Area]]         | [[Known Troublemaker]] |     |
| 2     | [[Area]]         | [[Known Troublemaker]] | Potential Bounty    |
| 3     | [[Area]]         | [[Lawbreaker]]         | Bounty    |
| 4     | [[Region]]       | [[Lawbreaker]]             | Wanted Alive    |
| 5     | [[Region]]       | [[Criminal]]                   | Wanted Alive    |
| 6     | [[Region]]       | [[Criminal]]                   | Wanted Dead or Alive    |
| 7     | [[Nation]]       | [[Enemy of the state]]                | Enemy of the state    |
| 8     | Multi-[[Nation]] | [[Enemy of the plane]]                  | Enemy of all (mortal and immortal)   |

