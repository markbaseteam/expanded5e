## (Background) Gatherer
 
You know where and how to get things — particularly arcane components, exotic ingredients and unusual materials. If you can’t get them yourself, you know someone who can. You have a knack for finding things that no one thought existed, and at half the	price one would have expected. 

**Skill Proficiencies:** Nature, Persuasion 
**Tool Proficiencies:** Herbalism Kit 
**Languages:** Two of your choice. 
**Equipment:** Six component pouches, 12 oiled sacks, protective gloves, pruning snips, skinning knife, 3 jars with preservation fluid, and a belt pouch with 24 gp. 

### Feature: Collecting 
You don’t necessarily know how to kill monsters, but once their dead, you know exactly what to take. When you come across exotic minerals, plants, animals or monsters, there is a good chance that you’ll know which parts are worth harvesting, and in what order of priority if time is an issue.

You also know almost every method of preservation that will allow you to keep whatever you find fresh until it reaches your client or the nearest market.

Over time, you have managed to learn the properties of  many mundane plants and how to use them in their raw state. 

### Suggested Characteristics 
The practice of alchemy requires an analytical mind and  an intuition about what will happen when ingredients are combined. The act of crafting a potion or poison requires extreme precision.

#### Personality Trait

| d8 | Personality Trait                                     |
|--------|-------------------------------------------------------|
| 1      | Tends to tell tall tales of great deeds to avoid past |
| 2      | Prefers the company of disreputable people            |
| 3      | Avid collector of baubles and trinkets                |
| 4      | Highly focused individual who sees tasks through      |
| 5      | Attracted to unique and bizarre                       |
| 6      | Known as the person who can get what you need         |
| 7      | Doesn't care about job as long as it involves travel  |
| 8      | Loves to gossip about people met                      |

#### Ideal
| d6 | Ideal                                                                                                                                  |
|--------|----------------------------------------------------------------------------------------------------------------------------------------|
| 1      | Professional. I am a man of my word. (Neutral)                                                                                         |
| 2      | Altruism. I prefer to take jobs that will make the world a better place in some way, and I don’t care if anyone knows about it. (Good) |
| 3      | Mercantile. The ebb and flow of wealth is what maintains order in the world. (Lawful)                                                  |
| 4      | Privateer. Yeah, I’ll take on a job, but if someone offers a better price, well... it’s just business. (Chaotic)                       |
| 5      | Heartless. I get whatever I need at all costs. (Evil)                                                                                  |
| 6      | Journey. I don’t really have a destination. It’s the journey that really matters. (Any)                                                |

#### Bond
| d6 | Bond                                                                                           |
|--------|------------------------------------------------------------------------------------------------|
| 1      | This ancient tome was given to me by my father. It is more valuable than my own life.          |
| 2      | The master who taught me my profession has given me purpose, and I owe him everything.         |
| 3      | This world provides all that is necessary. It must be preserved.                               |
| 4      | The support of those around me allows me to do what I love. I must never forget that.          |
| 5      | My brother was killed due to my inexperience. I must devote myself to perfection for his sake. |
| 6      | I own the keys to a secluded family manor that has been vacant for decades.                    |

#### Flaw
| d6 | Flaw                                                                                       |
|--------|--------------------------------------------------------------------------------------------|
| 1      | I must have the supplies I need to do my job, and I will do whatever it takes to get them. |
| 2      | My talents can do much good in the world. I must share them, whatever the personal cost.   |
| 3      | Some of my secrets must never be shared. Only I can handle the knowledge.                  |
| 4      | I must be the best! Impugning or destroying my competition is the only way.                |
| 5      | Laws regarding illegal ingredients don’t apply to me. They will simply never understand.   |
| 6      | I have become addicted to one of the ingredients I collect.                                |
