
Source: [[PDFs/Ability Traits.pdf]]

## Strength 
### Low Strength

| d8 | Personality Trait                                                                                                                                 |
|--------|---------------------------------------------------------------------------------------------------------------------------------------------|
| 1      | For you, violence is the last resort; you try any strategy before coming to blows.                                                          |
| 2      | Why should you do it, if somebody else can?                                                                                                 |
| 3      | You know your limits and you know when it's time to ask for help.                                                                           |
| 4      | You favor every way (lawful or not) that saves you from sweat and labor.                                                                    |
| 5      | You loathe your physique and cover yourself with large clothes and dresses.                                                                 |
| 6      | The world is a dangerous place and you don't know if you can fend for yourself. You keep close with the toughest of the group.              |
| 7      | Where strength doesn't reach, the mind comes first. You invest all your energies in studying, you find any occasion to learn something new. |
| 8      | You may be weakly now, but one day you'll be as tough as nails! You never tire of saying it and letting everyone know.                      |

### High Strength

| d8 | Personality Trait                                                                                                     |
|--------|-----------------------------------------------------------------------------------------------------------------|
| 1      | When the situation gets complicated, for you the best solution is strength.                                     |
| 2      | Someone is better than you? Impossible! You're as competitive as they get.                                      |
| 3      | You are incredibly pragmatic: for every problem there's a solution and you should quickly do it.                |
| 4      | You're very proud of your physical form and you never miss an occasion to show it.                              |
| 5      | You train with passion and diligence: push-ups, sit-ups and weightlifts are on the agenda daily.                |
| 6      | Many praise your strength, but you'd like to be considered for your other talents too.                          |
| 7      | You always worry for those less tough than you: the spot right in front of the danger should be yours to cover. |
| 8      | You know you can seriously hurt someone with one blow, as such you avoid brawls and wrangles.                   |

## Dexterity
### Low Dexterity

| d8 | Personality Trait                                                                                              |
|--------|----------------------------------------------------------------------------------------------------------|
| 1      | You never pay attention to your feet. Be it a root or a stair-step, you regularly stumble while walking. |
| 2      | You are clumsy, letting everything fall from your shaky hands.                                           |
| 3      | You know your limits; you always take purposeful and slow movements when needed.                         |
| 4      | Slow and steady wins the race. Whenever, you prefer to walk than to run.                                 |
| 5      | You are afraid of heights, you try to avoid also the smallest of altitude.                               |
| 6      | You maybe can't run, but horses can! You love horse races, not only as a spectator.                      |
| 7      | Dodging isn't your forte, but nobody wants to get hit. You never leave your armor or shield.             |
| 8      | You are not the best at hiding, but you don't care. You prefer to act in more direct ways.               |

### High Dexterity

| d8 | Personailty Trait                                                                                                                                  |
|--------|------------------------------------------------------------------------------------------------------------------------------------------------|
| 1      | You hate standing still. When sitting you can't stop stomping your feet, objects in your hand are nice improvised drums.                       |
| 2      | I'll go first! Whatever there is to do, you are the first to volunteer.                                                                        |
| 3      | You're so unnaturally quiet that when you start talking you scare people: they didn't notice you were there.                                   |
| 4      | You speak so fast, sometimes it's hard to understand what you are saying.                                                                      |
| 5      | You feel like your body is faster than your mind and end up acting before thinking.                                                            |
| 6      | This isn't your! You are so quick with your hands that sometimes you find yourself absentmindedly pickpocketing somebody.                      |
| 7      | You are posed and thoughtful, both in your opinion and in your movements. You know when to act quickly and when the smallest action is enough. |
| 8      | For every strike a parry. You never start a combat if not as in response to an attack                                                                   |

## Constitution 
### Low Constitution

| d8  | Personality Trait                                                                                                                                        |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | If it's not really necessary, why walk? A horse or a carriage are always a good option.                                                            |
| 2   | You are the definition of an hypochondriac: you live in fear contracting diseases.                                                                 |
| 3   | Your body is not used in living in rough conditions, you don't start a journey without all the necessary gear.                                     |
| 4   | You are afraid of battle scars, you prefer to maintain a good distance from any creature that seems aggressive.                                    |
| 5   | The world is full of toxic substances or stuff that will make you sick. You don't eat anything that it hasn't been tasted before by somebody else. |
| 6   | You are very sensible to cold. You bring with yourself lots of blankets and, when camping, you always take dibs on the spot near the fire.         |
| 7   | You can't stand the sight of blood, gore or any bodily fluids.                                                                                     |
| 8   | You always manage to take a good rest every day. You need an uninterrupted sleep to feel good.                                                     |

### High Constitution

| d8 | Personality Trait                                                                                                                                  |
|-----|----------------------------------------------------------------------------------------------------------------------------------------|
| 1   | Whatever it is you are doing, you can't keep your attention on a thing for long.                                                       |
| 2   | Animals are your best friends, oftentimes you relate better with them than with people.                                                |
| 3   | If a plan is needed, you stand back. You believe that any strategy coming from you will result in tragedy.                             |
| 4   | Your use of the language is poor, you often make mistakes and you are ashamed of it.                                                   |
| 5   | The weave of magic is unpredictable and dangerous. When there's a choice, it is better to adopt other methods.                         |
| 6   | When a situation becomes difficult to understand, you know that is better to ask than improvise.                                       |
| 7   | It doesn't matter how many times other people introduce themselves, you're never going to be able to match a face with the right name. |
| 8   | Even when you have good intuitions, rarely you find a way to put them into words and explain them to others.                           |

## Intelligence 
### Low Intelligence

| d8 | Trait                                                                                                                                  |
|--------|----------------------------------------------------------------------------------------------------------------------------------------|
| 1      | Whatever it is you are doing, you can't keep your attention on a thing for long.                                                       |
| 2      | Animals are your best friends, oftentimes you relate better with them than with people.                                                |
| 3      | If a plan is needed, you stand back. You believe that any strategy coming from you will result in tragedy.                             |
| 4      | Your use of the language is poor, you often make mistakes and you are ashamed of it.                                                   |
| 5      | The weave of magic is unpredictable and dangerous. When there's a choice, it is better to adopt other methods.                         |
| 6      | When a situation becomes difficult to understand, you know that is better to ask than improvise.                                       |
| 7      | It doesn't matter how many times other people introduce themselves, you're never going to be able to match a face with the right name. |
| 8      | Even when you have good intuitions, rarely you find a way to put them into words and explain them to others.                           |

### High Intelligence

| d8 | Description                                                                                                                                   |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| 1      | You know you are smarter than most people around you, and you are not afraid to let them know.                                                |
| 2      | For you every moment is good to sink into reading.                                                                                            |
| 3      | You often believe to have said something aloud, while in reality you only thought of it.                                                      |
| 4      | You remember every detail of the stuff is said or done to you; you do not hesitate in recalling this moments to blame others.                 |
| 5      | You believe to be always right and you are ready to present many arguments to sustain your opinion.                                           |
| 6      | You know an impressive number of words, even in different languages. Often your phrases contain complex terms, hard to understand for others. |
| 7      | You never trust fate. You refuse to play dice games, card games or take part in a bet.                                                        |
| 8      | You tend to focus on small details, losing sight of the bigger picture.                                                                       |

### Wisdom 
### Low Wisdom

| d8 | Description                                                                                                             |
|--------|-------------------------------------------------------------------------------------------------------------------------|
| 1      | You are a paranoid conspiracy theorist: behind every tragic story there's a bigger picture, drawn by imaginary enemies. |
| 2      | You've been deceived multiple times and now you don't trust anyone.                                                     |
| 3      | Even when unnecessary, you enrich your stories with half-truths and blatant lies.                                       |
| 4      | You often speak inappropriately, letting out information you shouldn't share, or indecorous comments.                   |
| 5      | You are very timid. You try to steer clear from any new situation to avoid ending up in an uncomfortable circumstance.  |
| 6      | You have an awful sense of direction: you avoid long travels or, if you really need to, you hire a guide.               |
| 7      | You distrust people coming from a culture different than yours.                                                         |
| 8      | You hardly doubt what others tell you, often resulting naive and gullible.                                              |

### High Wisdom

| d8 | Description                                                                                                           |
|--------|-----------------------------------------------------------------------------------------------------------------------|
| 1      | Before taking any action, you think long on it many, many, times.                                                     |
| 2      | You have such a strong sense of smell that you can't possibly stand strong odors.                                     |
| 3      | You are very patient, practically nothing can make you lose your temper. Almost nothing.                              |
| 4      | Hoping that your allies will always be at peace, you try to sedate every quarrel between them.                        |
| 5      | You take good care of your body and your health because deep down you know that the body is the temple of the soul.   |
| 6      | Your phrases often contain a common saying or a popular wisdom.                                                       |
| 7      | Your first choice is organic! You always prefer the natural version to the man made one.                              |
| 8      | You are known for your high adaptability. You always try to get the most even when there are few resources available. |

## Charisma 
### Low Charisma

| d8 | Description                                                                                                             |
|--------|-------------------------------------------------------------------------------------------------------------------------|
| 1      | A physical trauma has left great marks on your body, scarring your appearance and leaving you with a great fear.        |
| 2      | You are never properly dressed for the occasion.                                                                        |
| 3      | You have various pronunciation or stammering defects.                                                                   |
| 4      | Due to your great shyness, you are extremely introverted and silent.                                                    |
| 5      | You trust your companions so much that you believe that each one of their ideas is incredibly good.                     |
| 6      | If there is a clear decision to make, you don't back out, but when you need to bargain and argue, you let others do it. |
| 7      | Silence is golden. Often, for you, even the most heavenly melody is annoying.                                           |
| 8      | You are not a great follower of standard hygiene rules. Others often need to remind you to use soap.                    |

### High Charisma

| d8 | Description                                                                                                                                                           |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1      | You devote a great deal of attention and time to your appearance, so that you always look your best.                                                                  |
| 2      | You love talking about yourself.                                                                                                                                      |
| 3      | You are very talkative, and words flow smoothly from your mouth like a flooding river.                                                                                |
| 4      | You know that each person has a weakness that can be exploited to have them act to your advantage. For you, diplomacy or blackmail are better weapons than the sword. |
| 5      | You compliment all the people you talk to, for the sole purpose of making them more friendly to you.                                                                  |
| 6      | You are so used to having the attention of others that you can't stand being ignored.                                                                                 |
| 7      | Even in the face of the worst difficulties, you always react with a smile.                                                                                            |
| 8      | Whenever you tell a story, you always make yourself the protagonist.                                                                                                  |

