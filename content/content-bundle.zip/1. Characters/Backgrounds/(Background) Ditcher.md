# (Background) Ditcher

*OGL, Mixed Signals (www.mixedsignals.ml)*

You helped build castles by digging foundations and moats, and by cutting and laying stone.
Honest labor and a strong work ethic has kept you fed and sheltered, and it's also taught you a lot about castles and dungeons and related crafts.
You may have enjoyed your life as a ditcher, or it may have been imposed upon you. 
Either way, it was an eperience you'll never forget, and it always brings you some sense of pride to know that you helped build a structure expected to stand for centuries to come.

Decide why you were a laborer.
1. Were you forced into labor to pay off a debt, or because of a crime you committed, or was it just the family business? 
2. Was the project you were working on ever completed?
3. What was its purpose?
4. Was it a castle to protect a kingdom, a war machine, or a vanity project for a wealthy landowner?
5. Do you have fond memories of your hard labor? or nightmares?

**Skill Proficiencies:** Athletics, Intimidation
**Tool Proficiencies:** Mason's tools
**Equipment:** Traveler's clothes, mason's tools (your choice), measuring instruments, an ancient trinket you found in an excavation. A belt pouch containing 15 gp.
 
### Feature: Story of structure

You feel familiarity with great halls and large structures, and you glean knowledge from a structure's very construction.
Many structures throughout the realms have been corrupted by dark forces for new and unholy purposes; your GM may rule that you cannot successfully guess what those might be, but you are always able to divine the original purpose or lore engrained it the architecture and layout of a castle, crypt, dungeon, tomb, temple, or similar.

### Suggested Characteristics

A ditcher has worked hard for a great purpose, and never backs down from something that seems otherwise impossible.
Ditchers know that personal resolve, strength in numbers, and willful persistence can accomplish anything...eventually.

You may roll on these tables to develop your personality, or come up with traits of your own.

**d8 Personality Trait**

1. I appreciate architecture and craftsmanship in all its forms, from the humble to the grandiose.
1. I love constructing things, from idle toys to over-complex contraptions.
1. We build because we imitate the gods. My labor is an offering to the divine.
1. I did my time in hard labor, so now it's time for me to enjoy the good life.
1. Have I mentioned that I helped build the most magnificent structure in all the realms?
1. I'm an adventurer because I want to see the wonderful structures of ancient civilizations. 
1. I'm a simple person, but I love to dream big, and I believe everything is attainable. 

**d6 Ideal**

1. Structure is the key to civilized society and a peaceful life. (Lawful)
1. Charity. I toiled for the wealthy, now I work for the needy. (Good)
1. I learned how to build great structures so I would also know how to tear them down. (Chaotic)
1. I always see the job through. (Lawful)
1. We're all cogs in a great machine, each with our own unique purpose. (Neutral) 
1. Anyone can achieve greatness. (Any)

**d6 Bond**

1. I lost a friend in a suspicious accident. I'm out to find out what really happened.
1. I was never paid what I was owed for my labor, so I'm "fundraising" my wages.
1. An important structure in my hometown crumbled in a battle. I want to be the one to rebuild.
1. I want to preserve and cleanse the great ruins of the ancients.
1. For me, friendship is what a solid foundation is to a castle. 
1. Like stones blocks, only the strong can truly weather life's hardships.

**d6 Flaw**

1. I sometimes focus too much on a single task, forgeting to find new approaches to a problem.
1. In the work yards, we always had strict and clear plans. I don't improvise well.
1. I get annoyed by weaknesses in others.
1. I can't resist the desire to see every last detail of any building or structure I'm in.
1. I never give up. Never.
1. I have strong feelings about certain things, and I'm really bad at hiding them.