# (Background) Seeker

*Ethan Hudges, Curious Backgrounds, republished under the Open Game License*

You are a seeker of lost knowledge, traveling across the lands in search of some forgotten relic that haunts your dreams.
Whether this be the exploration of ancient ruins or in thorough study in every library, your every waking thought is to find this object.
1. What are you looking for? 
2. Why?
3. If you come from somewhere else, where is that place? 
4. Why is this object so important to you?

**Skill Proficiencies:** History, Investigation
**Tools:** Choose either Thieves' Tools or Musical Instrument
**Languages:** One additional
**Equipment:** Traveler's clothes, thieves' tools or a musical instrument, a small book full of notes, and a pouch containing 10gp
 
### Feature: Focused

Choose a single, particular object. 
You have advantage on any Intelligence checks in regards to that particular object (such as historical lore or magical properties) or people and places it has influenced (such as who may have the object now or where it is supposedly housed) as long as it is not in your possession. 
Should you then obtain that object, you can spend a week of thorough study and dreaming on another object to gain this feature again for that new object.

### Suggested Characteristics

Seekers switch between moods of intense focus to absolute absentmindedness.
Some would consider them unhinged, and they wouldn't be terribly incorrect. 
Things that bond the Seeker to the world might be the very object they seek, or the person or writing that set them on the path. 
Flaws could be that of anyone, but often center on the object of their obsession and how they view its importance.

You may roll on these tables to develop your personality, or come up with traits of your own.

**d8 Personality Trait**

1. I often daydream, thinking about that singular object.
2. I am as straight forward and focused as an arrow. And sometimes an arrow misses its mark. That's part of the fun.
3. I love the smell of dusty tomes. They smell like an age forgotten.
4. I like to sound mysterious. My obsession doesn't make sense to me, why should it to anyone else?
5. I am all about the journey. If my feet aren't on the road I feel as if I'm losing time.
6. In truth, I am afraid of ever finding the object. What purpose will my life have then?
7. Alongside my obsession, I also have a fascination with shoes. I wear only the finest of leathers with the most intricate of stitching.
8. I enjoy having a purpose in life, and do not envy those who wander through life aimlessly.

**d6 Ideal**

1. Peacebringer. I hope that the journey leads me to something that will allow me to make the world a better place. (Good)
2. Kingmaker. Perhaps the object is an ancestral memory, and by finding it I will discover my birthright. (Lawful)
3. Wanderlust. I don't much care about finding the thing I'm searching for. It is but a vehicle for adventure. (Chaotic)
4. Strength. The object I seek is one of great power. I must command it. (Evil)
5. Change. My journey will change the world. For better or worse, I know I must be there. (Neutral)
6. Obsession. I will seek my obsession to the very ends of the earth, or until the end of time. (Any)

**d6 Bond**

1. Journeying alone is rough, and I'm glad to have found companions willing to share the road with me.
2. I never knew my parents, and hope that whatever I'm looking for helps me discover who they were.
3. It was my mentor who set me out on their failed quest. I don't know why it was so important to them, but now I can't stop thinking about it.
4. I once had a friend with the same purpose as I. But their research led them elsewhere and I wonder if I will ever see them again.
5. There was another with the same dreams, but they plan on using the object for some nefarious scheme. I must find it before them.
6. I find a personal connection with the person who originally held the relic of my dreams. I wonder sometimes if I am that person.

**d6 Flaw**

1. I will do whatever it takes to find my obsession.
2. I can sleep soundly, but I am haunted by dreams almost nightly.
3. I often feel used, like a pawn in some greater scheme.
4. I know of my importance to the realm, and like others to know as well.
5. I do not pay attention to things that don't concern me or my quest. It would just be using otherwise precious space in my head.
6. I am incredibly secretive about my obsession. Others might think me mad, or wish to steal it.