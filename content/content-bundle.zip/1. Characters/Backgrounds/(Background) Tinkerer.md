# (Background) Tinkerer

*Ethan Hudges, Curious Backgrounds, republished under the Open Game License*

While not as commonplace as magic users who defy physics, some think to use the natural properties of the world to create incredible machines and devices that improve the simple lives of those around them. 
Tinkerers either work on these machines or live to make their own mark upon the world of burgeoning science.
1. How did you come into this profession? 
2. Why become an adventurer? 
3. What do you hope to build some day? 
4. What are your family’s thoughts on your path in life?

**Skill Proficiencies:** Arcana or Nature, Investigation
**Tools:** Choose either two Artisan's Tools or one  Artisan's Tools and one Thieves' Tools
**Equipment:** A leather apron, a Tinkerer's Bag (mechanical odds and ends, such as copper wire, small cogs, ane so on), and a pouch containing 10gp.

## Feature: Crafty

Given the opportunity and the time to thoroughly examine and deconstruct a device, you can replicate its construction assuming you have all the materials required. 
For simple items, you may assume you have the required components as part of your Tinkerer's Bag.
The time and price is up to the DM, but these periods of time need not be consecutively and may be done during any short rests (tinkers find deconstruction of mechanisms relaxing).

## Suggested Characteristics

More often than not, Tinkerers are highly intelligent and enthusiastic people. 

They highly value learning and self-discovery and enjoy the company of people to whom they can learn from, or argue. 

Teachers and other students of the craft are important to the Tinker, whether friend or rival, as the path of science cannot be embarked on alone. 

Consider flaws that deal with being misunderstood, ambitious and self defeating.

You may roll on these tables to develop your personality, or come up with traits of your own.

**d8 Personality Trait**

1. I am incredibly fidgety, and am only calm when I have something in my hands to work on.
2. When I look at something, I tend to stare at it for a long time trying to figure out how it works.
3. My favorite sound is the soft clicking of gears.
4. I like to be precise with my words, choosing specific language over incongruous poetics.
5. I know I'm the best, I just have to think of a way to prove it.
6. I often come up with my best ideas while puffing at my pipe.
7. A problem is just something I haven't figured out yet. Give me a moment, I'll get it.
8. The world is an amazing and fascinating place! I hope one day to see it all.

**d6 Ideal**

1. Industrious. My inventions will help the common folk, making their lives easier. (Good)
2. Empiricist. The best way to understand something is to test it, and then observe. Through this method, only then can we comprehend the universe. (Lawful)
3. Proof. I will prove that science has its place among the greatest of thinkers, and that magic is a bunch of hogwash. (Chaotic)
4. Merchant. I don't mind what my inventions are used for, as long as I profit from it. (Evil)
5. Salesman. I wish to sell my inventions to everyone, assuming they can pay the price. I'll be rich! (Neutral)
6. Scientist. Nothing is impossible. You just need the right idea to jump start it. (Any)

**d6 Bond**

1. Its my inventions that define who I am. They must be the very best.
2. My studies began after coming across an interesting old book with schematics. I hope one day to meet the author.
3. I want to hear my name called out at every market corner in every city. Only then will I know I succeeded.
4. Some villain had stolen my invention, and claimed the reputation that should have been mine.
5. My mentor was always misunderstood, and I hope to teach the world in his name the true teachings of science.
6. The principles of science are very dear to me, and I dislike the kinds of magicians who would destroy them.

**d6 Flaw**

1. I must document interesting phenomena. My craft demands it!
2. I am much more studious than gregarious, and don't ever think people will hear my name.
3. People are not worth my time. You can always trust a machine to do its job.
4. When my inventions do not work properly, I become furious or driven to drink.
5. I have a tendency to forget things I know I just had. “Where are my spectacles?” “They're on your head.”
6. I speak in a cacophony of highly intelligible techno-babble, uncaring if you understand it or not. I will not repeat myself either!