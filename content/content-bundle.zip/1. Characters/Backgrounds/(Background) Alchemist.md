## (Background) Alchemist

Ever since you were a small child, you have been fascinated to combine things to see what they become. When you were old enough, you began your apprenticeship with a local alchemist, and although you were never sure if it would become a career, you certainly learned many things that would help you in your every day life. Your cooking certainly improved. 

**Skill Proficiencies:** Medicine, Nature 
**Tool Proficiencies:** Alchemist’s Supplies 
**Languages:** Two of your choice. 
**Equipment:** A dozen empty potion bottles, one vile with an unknown potion, protective gloves, leather apron, common clothes, and a belt pouch with 8gp. 

### Feature: Alchemical Knowledge 

An alchemist knows his potions, whether they are simple herbal remedies, magical elixirs, or deadly poisons. You’ve seen many and read about many others, and so you are able to more easily identify a concoction, determine its likely properties, and glean many of its ingredients. In the case of poisons, you have an advantage to detecting its presence in a food or drink, or on a surface. 

### Suggested Characteristics 
The practice of alchemy requires an analytical mind and an intuition about what will happen when ingredients are combined. The act of crafting a potion or poison requires extreme precision.

#### Personality Trait
 | d6 | Personality Trait                                            |
|--------|--------------------------------------------------------------|
| 1      | Analytical mind, curiosity, and a drive to understand things |
| 2      | Mysteriousness, desire to cultivate an enigmatic image       |
| 3      | Expensive tastes, inclination to seek out wealthy supporters |
| 4      | Studiousness, a thirst for knowledge, a penchant for reading |
| 5      | Precision, attention to detail, commitment to accuracy       |
| 6      | Productivity, dedication to skill-building and practice      |

#### Ideal
| d6 | Ideal                  |
|--------|------------------------|
| 1      | Knowledge (Neutral)    |
| 2      | Beauty (Good)          |
| 3      | Logic (Lawful)         |
| 4      | No Limits (Chaotic)    |
| 5      | Power (Evil)           |
| 6      | Self-Improvement (Any) |

#### Bond
| d6 | Bond                                                                                        |
|--------|---------------------------------------------------------------------------------------------|
| 1      | It is my duty to protect my students.                                                       |
| 2      | I have an ancient text that holds terrible secrets that must not fall into the wrong hands. |
| 3      | I work to preserve a library, university, scriptorium, or monastery.                        |
| 4      | My life’s work is a series of tomes related to a specific field of lore.                    |
| 5      | I’ve been searching my whole life for the answer to a certain question.                     |
| 6      | I sold my soul for knowledge. I hope to do great deeds and win it back.                     |

#### Flaw
| Number | Flaw                                                        |
|--------|-------------------------------------------------------------|
| 1      | Easily distracted by the promise of information             |
| 2      | Stops to take notes on a demon's anatomy                    |
| 3      | Considers unlocking an ancient mystery worth a civilization |
| 4      | Prefers complicated solutions over obvious ones             |
| 5      | Speaks without thinking and often insults others            |
| 6      | Unable to keep secrets, even when lives are at stake        |
