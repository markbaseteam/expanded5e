## (Background) Caravaner

*OGL, Mixed Signals (www.mixedsignals.ml)*

You grew up traveling in a caravan, with no place to call home but the often dangerous roadways of the realms. 
The only reliable thing in your life was the interiour of your small vardo, carriage, or cart, and the knowledge that soon you'd be on the move again.
Even now, whenever you settle into a town for too long, you feel the urge to travel.
You are well-traveled if not cultured.
You know the layout of the land, and you have heard tales from far and wide, although you've never been sure what's true and what's a tall-tale.

Decide what manner of caravan you were in.
1. Was your caravan dedicated to mercantilism?
2. Or were you a performer in a traveling circus?
3. Maybe you were refugees from a war-torn land, on the move in search of permanency.
4. Were you traveling to find work?
5. Or were you just a group of habitual travelers?

Movement is progress, in your mind, and this may be something you embrace or it may be something you are struggling to suppress.

**Skill Proficiencies:** Persuasion, Survival
**Languages:** Two of your choice
**Equipment:** clothes befitting your life in the caravan (for example, merchant or circus attire), a map of an unidentified region, an old compass inherited by a mentor or family member, and a pouch containing 20 gp.
 
### Feature: Never a Stranger

As a former caravaner, you know the general customs of nearly every region you travel to, and can fit into most social circles naturally. Should you meet a caravan during your adventuring, it is likely that you can obtain a free meal and lodging for you and your party. You usually warrant a 50% discount on any goods or services a caravan happens to offer. 

### Suggested Characteristics

Any longtime caravaner, regardless of profession, has been shaped by life on the road.
They are well-versed in local tales and gossip, and they are able to make do with whatever life throws at them.
However, they often struggle to establish loyalty for people and places, inherently viewing everything as transitory, and they may tend to avoid dealing with problems they can otherwise literally move away from.

You may roll on these tables to develop your personality, or come up with traits of your own.

**d8 Personality Trait**

1. I act as a tour guide by impulse, pointing out features of lands and cities, whether I've been there or not.
1. I always want to know more about people I meet, asking them about their homeland and background.
1. It's fine here, but I'll bet it's even better over there.
1. I believe everyone should get out and travel more, and I'm eager to tell them where they should visit.
1. I draw and collect maps compulsively.
1. I've spent my entire life traveling, and I can't wait until I can finally settle down somewhere.
1. I'm used to sleeping on the ground and eating cold meat from a mess kit. I don't understand people who spend coin on luxuries.

**d6 Ideal**

1. Those I travel with are my family, and family comes before all else. (Lawful)
1. Charity. I always help a fellow traveler in need. (Good)
1. The more cultures and beliefs intermingle and mix, the better relationships between regions will be. (Chaotic)
1. Tradition is vital to the world and each culture's must be preserved. (Lawful)
1. The world endures ebbs and flows of fortune, and I've seen it all firsthand. There's no reason to interfere. (Neutral) 
1. Discovery. The realms are too vast to see everything, but you can't stop me from trying. (Any)

**d6 Bond**

1. I was separated from a family member by my travels. We're destined to reunite.
1. I was cast out of my caravan on a false charge. I'm going to get revenge on my accuser.
1. My caravan was attacked on the road, and I'm going to find out why.
1. Preserving the diverse cultures of this world is more important than anything.
1. I'm destined to be wealthy, all I have to do is figure out how to get there.
1. I believe sharing ideas is the key to resolving all conflict.

**d6 Flaw**

1. I never run from a fight, but I often run from personal problems.
1. I become restless and unfocused when stuck in one place for too long.
1. I've seen so much of the world that I sometimes think I know everything there is to know.
1. I see even my closest of friends as temporary, because I know there'll be another friend in the next city.
1. I am far too welcoming and trusting of strangers.
1. I can't resist exploring new places.