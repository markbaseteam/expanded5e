# (Background) Visionwalker

*Ethan Hudges, Curious Backgrounds, republished under the Open Game License*

Whether you were part of busy city church or lonely mountain monastery, you once followed the rites of your faith.

You know the songs of worship and understand the strictures more than any other citizen.
During one of your meditations, you had a vision explaining something to happen in the future.
1. What was this vision?
2. Is it why you began your journey, or was it an excuse to do so?
3. Do your betters believe you, or simply wish you out of their hair?

**Skill Proficiencies:** Religion, Insight
**Tools:** Herbalism kit
**Languages:** One additional
**Equipment:** Common clothes, a holy symbol, a pilgrim's cloak, an Herbalism Kit, pouch with 10gp.

### Feature: Visionary

You are identified as possessing a unique ability by high-level priests and clerics.
It's not unusual for you to receive offers of free healing and other blessings from local temples.
You make friends with, or at least attract friendly reactions from, holy people easily and often.

### Suggested Characteristics

Visionaries are not necessarily monks or clerics. 
They can just as easily be farmers or merchants. 
Where they all meet are a fervent belief in their faith. 
Your traits and bonds should reflect your relationship with your faith and your patron deity.
Flaws might reflect misunderstandings in your teachings, or problems your faith gives you when interacting with others.

You may roll on these tables to develop your personality, or come up with traits of your own.

**d8 Personality Trait**

1. I am calm and reserved, preferring quiet meditation over lively chanting.
2. There is beauty and meaning in everything, and I hope to point that out to those around me.
3. I do not easily get upset. That does not mean I am a pacifist, however.
4. I prefer to use the words of great people in place of my own.
5. I am a paragon of my deity and believe in them unerringly.
6. I love bees. The are incredibly industrious and always do their job. I wish we were more like them.
7. I prefer simple solutions to every problem, and try not to think too long on anything.
8. My first instinct is to help. The best way to prove your faith is through action.

**d6 Ideal**

1. Savior. Through my trials, my vision promises to improve the world. (Good)
2. Servant. I follow the scriptures of my faith. I believe in them, and that they are the correct path to improving the self, and the world. (Lawful)
3. Heretic. The people of my faith find my visions heretical, but I will prove to them the power of my faith. (Chaotic)
4. Crusader. I give no quarter to the enemies of my faith. They deserve not my kind words. They deserve retribution. (Evil)
5. Convert. I had never been the most faithful disciple, and find this whole “vision” thing unsettling. I must see it through, whatever it might have in store for me. (Neutral)
6. Pilgrim. I know nothing but my faith. I journey to learn about the world, and hope to have the pieces of my vision fall into place. (Any)

**d6 Bond**

1. The church is all I've ever known. They are my family, and it saddens me to have to leave them.
2. I have a personal connection with my deity. I was chosen by them, and I am their loyal servant.
3. The head of my church did not believe me, and I journey to prove to them wrong.
4. I have no connection with anyone or anything. They would simply distract me from my purpose.
5. My traveling companions may not believe me or my faith, but I am glad to have them and teach them the ways of my deity.
6. I have a small object let by my parents. It is the only thing I have to remember them by, and hope that one day leads me to them.

**d6 Flaw**

1. I must encourage everyone to follow my path, as it is the only path to salvation.
2. Because I have seen the future, I know that I am in it. I take risks I probably otherwise wouldn't.
3. I find my visions easiest after I have indulged in the world's pleasures.
4. I like to give my deity credit for everything, regardless of their involvement or interest.
5. I was taught that violence was never the answer. I have proven that incorrect more than once.
6. I have no time for the faithless. Do they not understand the importance of keeping ourselves in the gods' favor?