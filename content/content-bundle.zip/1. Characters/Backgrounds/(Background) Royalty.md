# (Background) Royalty

*Ethan Hudges, Curious Backgrounds, republished under the Open Game License*

You belong to the highest of families among the Nobility. 

Yours is a life of parties, performances and magic high above the earthly troubles of the world.
You have been tutored by the wisest of mages and the most beautiful of artists to hone your own skills of courtship, magic and the ruling of a nation.

But such a life can be boring, and those of the nobility who wish to experience the world can only truly do so disguised.
1. What do you want out of your adventure? 
2. Do you think you are ready to live life without servant or shelter from the worst of the world?
3. How well do you think you can adapt to being an adventurer?

**Skill Proficiencies:** Arcana, Performance
**Tools:** Disguise kit
**Languages:** One additional
**Equipment:** A set of high quality Traveler's Clothes, a royal pendant, a Disguise kit and a purse containing 20gp.

### Feature: Diamond among the Rough

Choose an alter ego.
This person may not be someone that already exists.
You have all the required paperwork involved in being of your alter ego's station, and have advantage on any checks involved in playing that person. 
Disguising yourself as your alter ego takes half the time necessary.
Should another creature discover your true identity they will treat you appropriately for someone of your station, but it is up to the DM (or player if it is a PC) to determine the ramification of this knowledge.

### Suggested Characteristics

As a member of high nobility, your personality traits might reflect a very trained, but naive demeanor. 
You might have an unexplained grace or authority in your steps that you cannot hide. Bonds might involve family, tutors or secret friends who got the idea of adventuring in your head in the first place.
Flaws should reflect a sheltered life and misinformation about the world around them.

You may roll on these tables to develop your personality, or come up with traits of your own.

**d8 Personality Trait**

1. I speak eloquently and correctly, and encourage others to do the same.
2. I am graceful in my movements and ways, almost as if performing a dance with every step.
3. No matter how I try and hide it, my voice commands respect.
4. I am very uncertain about the world and often appear timid until I know more about it.
5. I yearn for adventure, and will not be stopped from experiencing all that life has to offer before I am returned to my cage.
6. I still enjoy a good party, and will drop everything to join in the fun.
7. Animals must be able to sense my nobility. The flock to me and we sing the songs of the world together.
8. I prize the most handsome of clothes, but know better than to wear them in my new life.

**d6 Ideal**

1. Equality. I believe that in their hearts, everyone is the same. They just wear different hats. (Good)
2. Respect. Even in secrecy, I demand respect be given to me and to those around me. (Lawful)
3. Freedom. People should be allowed to do as they wish, regardless of station. (Chaotic)
4. Servitude. In time, everyone will live to serve me. For now, I gauge how best to use them. (Evil)
5. Independence. I do not wish for any obligation to be thrown at me. I simply wish to live. (Neutral)
6. Rule. I will one day rule the lands. I hope to learn all I can about them before then. (Any)

**d6 Bond**

1. I greatly respect my parents, not because of their birth right but because of their accomplishments. I hope to someday meet, and then surpass, their expectations of me.
2. It is my tutors I have to thank for instilling a wanderlust in my heart, and I wish to continue to learn in their memory.
3. It was a poor merchant's child who first showed my life beyond the castle walls, and who taught me the thrill of adventure.
4. My older sibling got to ride off to war while I was young, and I still envy them that opportunity.
5. I was kidnapped as a child, and while a terrifying experience thank those responsible for showing me the world is far bigger than my own inside the castle.
6. I've had a fascination with the tales heroes all my life, and wish that I can one day be as great as them.

**d6 Flaw**
1. I am prone to revealing my position when I do not get my way.
2. I prefer not to touch things, especially if they might be dirty.
3. I refuse to do any hard labor, and will trick or pay others to work in my place.
4. I will one day rule these lands. Everyone is below me.
5. I still enjoy a good party, and will drop everything to join in the fun. Perhaps a little too much.
6. I believe in excess and will spend my coin on extra food, drink and clothing.