A character must satify daily hunger to ensure they can rest correctly and do not suffer from both mental or physical [[Exhaustion]]. To do this they must eat for each hour awake. 

If entering initiative this automatically counts as an hour on top of the normal time awake. The players need to take into account the factors impacting hunger below.

Travelling fast, in [[Rough Terrain]], or [[Dangerous conditions]] cost double per hour.

So an average sized human wearing leather armor would have the following multipliers;
	1 (medium) x 1 (81-129 weight) x 1(Armor) = 1 
But a mountain dwarf with heavy armor would be
	1 (medium) x 1 1/2 (130-180 weight) x 2 (Armor) = 3

Each food source has a hunger point value. If not stated the default is the following;
1. 1 serving uncooked (1 hour)
2. 1 meal cooked (6 hours)
3. 1 daily rations (15 hours)

## Factors impacting hunger
The one point of food per hour satification rules are running on the assumption of the player being of medium size. There are also some factors including weight and weight of armor that must be taking into account. Always round up.

| Size       | Multiplier |
|------------|------------|
| Tiny       | 1/4        |
| Small      | 1/2        |
| Medium     | 1          |
| Large      | 1 1/2      |
| Huge       | 2          |
| Gargantuan | 4          |

## Hunger and weight

| Weight Range | Multiplier |
|--------------|------------|
| 10-50        | 1/4        |
| 50-80        | 1/2        |
| 81-129       | 1          |
| 130-180      | 1/2        |
| 181-250      | 2          |
| 250-400      | 2 1/2      |

## Hunger and Armor

| Armor Type | Multiplier |
|------------|------------|
| None       | 1          |
| Light      | 1          |
| Medium     | 1          |
| Heavy      | 2          |

