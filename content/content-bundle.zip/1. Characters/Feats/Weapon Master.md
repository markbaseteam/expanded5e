## Weapon Master

You gain proficiency with 4 weapon styles of your choice: Staff, Hammer, Axe, Sword, Puncture, Thrust, Whip, Chained, Bow, Crossbow, or Unarmed. 