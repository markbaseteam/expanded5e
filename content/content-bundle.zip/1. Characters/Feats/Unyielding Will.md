# Unyielding Will

No one comes into your house and pushes you around. You gain the following benefits:

- Increase your Charisma score by 1, to a maximum of 20.
- Other creatures cannot read your thoughts without your consent.
- You gain resistance to psychic damage.