## Sentinel

You have mastered techniques to thwart a creature’s attempt to escape you, gaining the following benefits:

- Whenever you hit a creature with an [[Opportunity attacks]], its speed is reduced by 15ft until the end of its next turn. 
- Creatures provoke [[Opportunity attacks]] from you when attempting to leave your reach, even if they wouldn't normally provoke Opportunity Attacks.
- When a creature within your reach makes an Attack against a target other than you, you can use your [[Reaction]] to make a Melee Weapon Attack against the attacking creature.