## (Feat) Potion master
Your experience with potions is quite extensive, and so you have gained the following benefits: 
- You have an [[Advantage]] when attempting to identify a potion by sampling it.
- When identifying a potion, you gain a greater insight into its effects, including things such as duration, ingredients and any adverse side effects. 
- You are able to create most common nonmagical potions from local herbs and fungi, assuming the ingredients are readily available. This can be done even under somewhat adverse conditions.
- You have an [[Advantage]] to any rolls related to crafting magical potions, assuming that you have all the materials and tools necessary. 