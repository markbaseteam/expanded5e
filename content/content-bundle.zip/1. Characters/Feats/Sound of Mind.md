# Sound of Mind

Your mind is an oasis of calm in a chaotic world. You gain the following benefits:

- Increase your Wisdom score by 1, to a maximum of 20. 
- If an effect would cause you to make a Constitution check to maintain [[concentration]] on a spell or effect, you may use your [[reaction]] to automatically succeed on that check. 
- You have [[Advantage]] on Wisdom saving throws against being charmed or frightened. 