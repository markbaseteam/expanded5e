## Lucky

When you make an Attack, Check, or Save you can choose to gain [[Advantage]] on it. You can use this ability 3 times per Long Rest.