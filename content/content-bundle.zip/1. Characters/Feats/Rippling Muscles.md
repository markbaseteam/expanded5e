# Rippling Muscles

Your meaty brawn is thicker than leather armor. You gain the following benefits:

- Increase your Strength score by 1, to a maximum of 20. 
- While unarmored, you gain a bonus to your Armor Class equal to your Strength modifier.
- You have [[Advantage]] on all Strength (Athletics) checks made to break bonds that restrain you. 