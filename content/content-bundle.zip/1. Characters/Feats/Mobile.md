## Mobile

Your speed is increased by 10ft and when you take the Dash Action, difficult terrain doesn't cost extra movement on that turn.