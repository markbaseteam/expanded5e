## Grappler

*Prerequisite: Strength 13 or higher*

You've developed the skills necessary to hold your own in close-quarters [[Grapple]]. You gain the following benefits: #Feat

- You have [[Advantage]] on [[Attack Rolls]] against a creature you are [[Grapple]].
- When a hostile creature's movement provokes an [[Opportunity Attack]] from you, you can use a [[Reaction]] and [[Grappled]] it instead.
- You can use a [[Bonus Action]] to attempt to [[Grappled]] a creature.
- You can use your action use [[(Rule) Advanced Grapple Options]] on a creature [[Grappled]] by you. 
- You can use an action to make another grapple check. If you succeed, you and the creature are both [[Restrained]] until the grapple ends.



