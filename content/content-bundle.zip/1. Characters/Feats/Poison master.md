## (Feat) Poison master
You have mastered the art of using poisons, and have developed the following abilities:
- You gain poison [[Resistance]] due to prolonged exposure to many different poisons, venoms and toxins.
- You can more easily sense the presence of poison, whether it’s in food, drink, coating a blade, or on some surface. You have an [[Advantage]] on any check related to detecting poisons. 
- You have an [[Advantage]] on all rolls related to handling or crafting poisons. 