## Sharpshooter

Attacking at long range doesn't impose [[Disadvantage]] on your Ranged Weapon Attacks. Your Ranged Weapon Attacks ignore [[Half Cover]] and [[Three-quarters cover]]. Before you make an Attack with a Ranged Weapon you are proficient with, you can choose to subtract your Prof. Bonus from the Attack. If the Attack hits, you add twice your Prof. Bonus to the Attack’s damage.

***DC Tip:*** These both scale better than the -5/+10 mechanic and aren’t as broken at early levels. Dealing an extra 10 damage at levels 5 and lower is pretty crazy, so this method ties the hit and damage to your Prof. Bonus. You will start off having a -2 to hit for +4 damage and then eventually scale to a -6/+12 at higher levels.