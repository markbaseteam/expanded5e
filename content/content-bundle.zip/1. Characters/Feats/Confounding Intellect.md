# Confounding Intellect
You might not be the most popular person, but no one can deny your genius. You gain the following benefits:

- Increase your Intelligence score by 1, to a maximum of 20. 
- You may add your Intelligence bonus to Charisma (Persuasion) and Charisma (Deception) checks.
- You may use Intelligence as your spellcasting ability for any spell you cast.