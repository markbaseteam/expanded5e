## Great Weapon Master

On your turn, when you score a [[Critical Hit]] with a Melee Weapon or reduce a creature to 0 HP with one, you can make 1 Melee Weapon Attack using a [[Bonus Action]]. Before you make an Attack with a Melee Weapon you are proficient with, you can choose to subtract your Prof. Bonus from the Attack. If the Attack hits, you add twice your Prof. Bonus to the Attack’s damage.