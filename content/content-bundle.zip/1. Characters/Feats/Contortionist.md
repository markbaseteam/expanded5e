# Contortionist

Your joints allow flexibility that others find disconcerting. You gain the following benefits:

- Increase your Dexterity score by 1, to a maximum of 20. 
- If an object would provide you with ½ or ¾ [[Cover]], it provides you with full cover instead. 
- You may squeeze through a space that is large enough for a creature one size smaller than you without spending extra movement. You do not have [[Disadvantage]] on [[Saving throws]] or [[Attack Rolls]] while such a space, and attack rolls against you are not made with [[Advantage]].