# Iron Fortitude

Nothing beats a good night’s sleep — but you can just as easily get by without. You gain the following benefits:

- Increase your Constitution score by 1, to a maximum of 20.
- When you finish a long rest, you gain temporary hit points equal to 1d8 plus your Constitution modifier.
- You can go without a night’s sleep without taking a level of exhaustion.
