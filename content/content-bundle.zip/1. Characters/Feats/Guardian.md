## Guardian

You have mastered techniques to guard and defend your allies, gaining the following benefits: You can't be [[Surprised]] while you aren't Incapacitated. When a creature hits a target other than you with a Melee Weapon Attack, you can use a Reaction to perform 1 of the following actions if the target of the Attack is within your reach:

-  Reduce the damage of the Attack by an amount equal to your Attack Modifier + your Prof. Bonus, as you deflect the strike away from the target. 
-  Become the target of the Attack instead, leaping in front of the target before returning to your space.