## ACOKANTHERA   
### ACOKANTHERA 

*[[Large]] #plant (shrub)* 

**Terrain**  Coast, forest  

**Frequency** Rare  

**ID DC**  12 (grapes, berries [food]) 

**Type**  Ingestion DC 16 ([[Advantage]]), Injury DC 16 

**Ingestion Onset** 2d20 minutes  

***Protection from Poison*** Neutralizes  

**Medications** None 

**Symptoms** Twitching of the neck and chest muscles, respiratory 

distress, and cardiovascular disturbance 

**Traits** Animals, poisoned caltrops, food, weapon poison 

**Challenge** 1/2 (100 XP)  

Also known as the poison arrow plant, this flowering bush is a common source of weapon poisons. The toxins are absorbed poorly through ingestion. If the toxins enter the bloodstream directly, they act at their full potency. It is one of several closely related plants with similar traits. 

One subspecies produces edible fruit, which contributes to the risk of accidentally eating this plant.   

***Ingestion.*** Creatures that ingest this poison have [[Advantage]] on their saving throws and resistance to the damage. 

***Animals.*** Some #rat sub-species (including [[giant rat]] and [[were-rat]] creature variants) chew the roots of the acokanthera and spread the masticated paste on their flanks where specialized, barbed hairs absorb the toxin. Anyone grappling with these rats or striking them with an unarmed attack is pierced by the barbed hairs and exposed to the poison.  

***Poisoned Caltrops.*** The caltrop-like seeds of the puncture plant (tribulus terrestris) can be smeared with the acokanthera’s toxic sap and scattered on the ground to trap an area.  

***Weapon*** ***Poison.*** Any character proficient with cook’s utensils, herbalism kits, or alchemy kits can extract the poison from the acokanthera (no check required). Other characters must make a DC 10 Intelligence (Nature) Check to extract the poison. A creature subjected to this poison must make a DC 16 Constitution saving throw or take 21 (6d6) poison damage and be weakened for 1d4 hours. If the save succeeds, the creature  takes half as much damage and is weakened for 1 hour. If the saving throw failed by 5 or more, the creature takes another 21 (6d6) poison damage and is also
incapacitated with convulsions for 1 hour.  

***Food.*** Creatures might eat this plant during famine. Its fruit may be mistaken for grapes. Characters not proficient with cook’s utensils must make a DC 10 Intelligence (Nature) check to prepare [[Acokanthera berries]] that are safe to consume. 