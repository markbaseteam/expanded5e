## ACKEE 
### Ackee 

*[[Gargantuan]] #plant (tree)* 

**Terrain**; #Forest, #urban  

**Frequency**; #Uncommon  

**ID DC**;  (8) ackee fruit (apple [food]) 

**Type**  Ingestion DC 16 

**Ingestion Onset**; 2d12 minutes  
***Protection from Poison***; [[Advantage]] and [[Resistance]] only  

**Medications**; Colds, fever, edema, and epilepsy 

**Symptoms**; Sudden, violent vomiting and seizures 

**Traits**; Fish poison, food, industrial uses  

**Challenge** 1/4 (50 XP)  

The evergreen ackee grows up to thirty-feet tall and produces [[Ackee]] fruit throughout the year. The ripened fruit is safe to eat, but the unripe fruit contains deadly toxins.  

***Ingestion.*** A creature that ingests unripe [[Ackee fruit]] must succeed on a DC 16 Constitution saving throw, taking 21  (6d6) poison damage on a failed save, or half as much damage on a successful one. If the saving throw failed by 5 or more, the creature takes another 10 (3d6) poison damage and falls unconscious for 1d6 hours.  

***Industrial Uses.*** Ackee wood is used in foundations, oars, and casks. A fragrant perfume can be made from the flowers.   

***Fish Poison.*** The ackee’s unripe fruit can be pounded into a mash to make [[Fish Poison]] and dumped into a lake, pond, or other body of still water. One dose poisons the water in a 10-foot radius sphere for 10 minutes. Any aquatic creatures (including sahuagin and mer-folk) that enter the affected area or begin their turn there must make a DC 14 Constitution saving throw. They take 7 (2d6) poison damage on a failed save, or half as much on a successful one.  

***Food*** ***.*** Characters proficient with cook’s utensils can automatically prepare meals of safe ackee fruit. Other characters must make a DC 8 Intelligence (Nature) check to avoid eating toxic ackee fruit