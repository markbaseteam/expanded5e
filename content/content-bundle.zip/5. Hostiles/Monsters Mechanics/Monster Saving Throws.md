## Monster Saving Throws

The Saving Throws entry is reserved for creatures that are adept at resisting certain kinds of effects. For example, a creature that isn't easily charmed or frightened might gain a bonus on its Wisdom saving throws. Most creatures don't have special saving throw bonuses, in which case this section is absent.

A saving throw bonus is the sum of a monster's relevant ability modifier and its proficiency bonus, which is determined by the monster's challenge rating (as shown in the Proficiency Bonus by Challenge Rating table).

**Table- Proficiency Bonus by Challenge Rating**

| Challenge | Proficiency Bonus |
|-----------|-------------------|
| 0         | +2                |
| 1/8       | +2                |
| 1/4       | +2                |
| 1/2       | +2                |
| 1         | +2                |
| 2         | +2                |
| 3         | +2                |
| 4         | +2                |
| 5         | +3                |
| 6         | +3                |
| 7         | +3                |
| 8         | +3                |
| 9         | +4                |
| 10        | +4                |
| 11        | +4                |
| 12        | +4                |
| 13        | +5                |
| 14        | +5                |
| 15        | +5                |
| 16        | +5                |
| 17        | +6                |
| 18        | +6                |
| 19        | +6                |
| 20        | +6                |
| 21        | +7                |
| 22        | +7                |
| 23        | +7                |
| 24        | +7                |
| 25        | +8                |
| 26        | +8                |
| 27        | +8                |
| 28        | +8                |
| 29        | +9                |
| 30        | +9                |
|           |                   |
