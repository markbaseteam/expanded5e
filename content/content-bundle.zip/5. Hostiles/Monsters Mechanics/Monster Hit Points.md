## Monster Hit Points

A monster usually dies or is destroyed when it drops to 0 hit points. 

A monster's hit points are presented both as a die expression and as an average number. For example, a monster with 2d8 hit points has 9 hit points on average (2 × 4½).

A monster's size determines the die used to calculate its hit points, as shown in the Hit Dice by Size table.

**Table- Hit Dice by Size**

| Monster Size | Hit Die | Average HP per Die |
|--------------|---------|--------------------|
| Tiny         | d4      | 2 1/2              |
| Small        | d6      | 3 1/2              |
| Medium       | d8      | 4 1/2              |
| Large        | d10     | 5 1/2              |
| Huge         | d12     | 6 1/2              |
| Gargantuan   | d20     | 10 1/2             |
|              |         |                    |

A monster's Constitution modifier also affects the number of hit points it has. Its Constitution modifier is multiplied by the number of Hit Dice it possesses, and the result is added to its hit points. For example, if a monster has a Constitution of 12 (+1 modifier) and 2d8 Hit Dice, it has 2d8+2 hit points (average 11).
