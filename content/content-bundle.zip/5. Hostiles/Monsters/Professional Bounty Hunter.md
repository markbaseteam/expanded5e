## Professional Bounty Hunter 

*[[Medium]] #humanoid (any race), any alignment* 

**Armor Class** 17 (splint) 

**Hit Points** 58 (9d8 + 18) 

**Speed** 30 ft. 

| STR     | DEX    | CON     | INT     | WIS     | CHA     |
| ------- | ------ | ------- | ------- | ------- | ------- |
| 16 (+3) | 14 (+2) | 14 (+2) | 10 (+0) | 12 (+1) | 10 (+0) |

**Skills** Athletics +5, Perception +3, Survival +3, Stealth +4 

**Senses** passive Perception 12 

**Languages** any one language (usually Common) 

**Challenge** 3 (700 XP) 

###### Actions

**Multiattack.** The bounty hunter makes two longsword attacks. If it has a shortsword drawn, it can also make a cudgel attack. 

**Longsword.** *Melee Weapon Attack*: +5 to hit, reach 5 ft., one target. *Hit:* 7  (1d8  +  3) #slashing  damage,  or  8  (1d10+3) slashing damage if used with two hands.
**Cudgel.** *Melee  Weapon  Attack*: +5  to hit, reach 5 ft., one target. Hit: 6 (1d6 + 3) #bludgeoning damage. 
**Heavy Crossbow.** *Ranged Weapon Attack:* +4 to hit, range 100/400 ft., one target. Hit: 6 (1d10+1) #piercing damage. 
**Bola.** A bola is a cord with weights on each end thrown at the legs of a fleeing target. *Ranged Weapon Attack:* +4, range 30/50., one target. *Hit:* (1d4+2) bludgeoning damage. A large or smaller creature hit must succeed in a DC 13 Dexterity saving throw or become [[Grappled]]. DC 12 Strength check to break. The bola has 4 hit points.  

A bounty hunter may use a [[Bola]] during an attack of opportunity even if the target has used the Withdraw action. 

**Professional** **Bounty Hunters** **are tough and dogged in** **their pursuit, but they’re also experienced enough to** **know when a target is out of their league.** **They’ll** **team up with other bounty hunters if they have to,** **but they’ll also hire mercenaries or even work with** **enemies of the target.**