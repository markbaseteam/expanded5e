## Detective

*[[Medium]] #humanoid (any race), any alignment* 

**Armor Class** 12 

**Hit Point**s 27 (6d8) 

**Speed** 30 ft. 

| STR     | DEX    | CON     | INT     | WIS     | CHA     |
| ------- | ------ | ------- | ------- | ------- | ------- |
| 10 (+0) | 15 (+2) | 10 (+0) | 12 (+1) | 14 (+2) | 16 (+3) |

**Skills** Deception +5, Insight +4, Investigation +5, Perception +6, Persuasion +5, Sleight of Hand +4, Stealth +4 

**Senses** passive Perception 16

**Languages** any two languages 

**Challenge** 1 (200 XP) 

***Cunning Action.*** The detective uses a [[bonus action]] to [[Dash]], [[Disengage]], or [[Hide]]. 

***Sneak Attack (1/Turn) .*** The detective deals an extra 7 (2d6) damage when it hits a target and has [[Advantage]] on the attack roll, or when the target is within 5 feet of an ally that isn’t incapacitated and the detective doesn’t have [[Disadvantage]] on the attack roll. 

###### Actions

***Multiattack.*** The spy makes two melee attacks. 

***Shortsword.*** *Melee Weapon Attack:* +4 to hit, reach 5 ft., one target. *Hit:* 5 (1d6 + 2) #piercing damage. 