### Sea Horse

*Tiny #beast, unaligned*

**Armor Class** 11

**Hit Points** 1 (1d4-1)

**Speed** 0 ft., swim 20 ft.

| STR    | DEX     | CON    | INT    | WIS     | CHA    |
|--------|---------|--------|--------|---------|--------|
| 1 (-5) | 12 (+1) | 8 (-1) | 1 (-5) | 10 (+0) | 2 (-4) |

**Senses** passive Perception 10

**Languages** -

**Challenge** 0 (0 XP)

***Water Breathing***. The sea horse can breathe only underwater.