### Giant Fly

*Large #beast, unaligned*

**Armor Class** 11

**Hit Points** 19 (3d10+3)

**Speed** 30 ft., fly 60 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 14 (+2) | 13 (+1) | 13 (+1) | 2 (-4) | 10 (+0) | 3 (-4) |

**Senses** darkvision 60 ft., passive Perception 10

**Languages** -
