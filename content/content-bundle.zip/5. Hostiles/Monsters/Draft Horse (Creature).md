### Draft Horse

*Large #beast, unaligned*

**Armor Class** 10

**Hit Points** 19 (3d10+3)

**Speed** 40 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 18 (+4) | 10 (+0) | 12 (+1) | 2 (-4) | 11 (+0) | 7 (-2) |

**Senses** passive Perception 10

**Languages** -

**Challenge** 1/4 (50 XP)

###### Actions

***Hooves***. *Melee Weapon Attack:* +6 to hit, reach 5 ft., one target. *Hit:* 9 (2d4+4) bludgeoning damage.