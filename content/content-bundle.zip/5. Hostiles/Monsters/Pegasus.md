## Pegasus

*Large #celestial, [[Chaotic Good]]*

**Armor Class** 12

**Hit Points** 59 (7d10+21)

**Speed** 60 ft., fly 90 ft.

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 18 (+4) | 15 (+2) | 16 (+3) | 10 (+0) | 15 (+2) | 13 (+1) |

**Saving Throws** Dex +4, Wis +4, Cha +3

**Skills** Perception +6

**Senses** passive Perception 16

**Languages** understands Celestial, Common, Elvish, and Sylvan but can't speak

**Challenge** 2 (450 XP)

###### Actions

***Hooves***. *Melee Weapon Attack:* +6 to hit, reach 5 ft., one target. *Hit:* 11 (2d6+4) bludgeoning damage.