## Bounty Hunter Mage 

*[[Medium]] #humanoid (any race), any* *alignment* 

**Armor Class** 12 (15 with *[[Mage Armor]]*) 

**Hit Points** 40 (9d8) 

**Speed** 30 ft. 

| STR     | DEX    | CON     | INT     | WIS     | CHA     |
| ------- | ------ | ------- | ------- | ------- | ------- |
| 9 (-1) | 14 (+2) | 11 (+0) | 17 (+3) | 12 (+1) | 11 (+0) |

**Saving Throws** Int +6, Wis +4 

**Skills** Arcana +6, History +6 

**Senses** passive Perception 11 

**Languages** any four languages 

**Challenge** 6 (2,300 XP) 

***Spellcasting.*** The mage is a 9th-level spellcaster. Its spellcasting ability is Intelligence (spell save DC 14, +6 to hit with spell attacks). The mage has the following wizard spells prepared: 

Cantrips (at will): *[[Fire Bolt]]*, *[[Light (Spell)]]*, *[[Message]]*, *[[Ray of Frost]]* 
1st level (4 slots): *[[Detect Magic]]*, *[[Mage Armor]]*, *[[Magic Missile]]*, *[[Sleep]],* *[[Disguise Self]]* 
2nd level (3 slots): *[[Ray of Enfeeblement]]*, *[[Suggestion]], [[Hold Person]],*  
3rd level (3 slots): *[[Counterspell]]*, *[[Fly]],* *[[Clairvoyance]]* 
4th level (3 slots): *[[Greater Invisibility]]*, *[[Locate Creature]],* *[[Polymorph]]* 
5th level (1 slot): *[[Dominate Person]]* 

###### Actions 

***Staff.*** *Melee Weapon Attack:* +5 to hit, one target.  *Hit:* 7 (1d8 + 2) bludgeoning damage. 

**Though they are often looked down on by their more** **studious peers, some mages turn to bounty hunting as** **a  profession  to  fund  their  research  or  pay  for  more** **materials.  Bounty  hunter mages focus on spells  that** **can bring** **a target in alive.** 