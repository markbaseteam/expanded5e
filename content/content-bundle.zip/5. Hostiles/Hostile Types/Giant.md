**Giants** tower over humans and their kind.
They are humanlike in shape, though some have multiple heads (ettins) or deformities (fomorians). 
The six varieties of true giant are hill giants, stone giants, frost giants, fire giants, cloud giants, and storm giants. 
Besides these, creatures such as ogres and trolls are giants.