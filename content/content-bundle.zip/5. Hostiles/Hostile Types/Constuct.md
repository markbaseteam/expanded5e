**Constructs** are made, not born. 
Some are programmed by their creators to follow a simple set of instructions, while others are imbued with sentience and capable of independent thought.