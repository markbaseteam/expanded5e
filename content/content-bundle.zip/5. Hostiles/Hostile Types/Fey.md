**Fey** are magical creatures closely tied to the forces of nature.
They dwell in twilight groves and misty forests. 
In some worlds, they are closely tied to the Feywild, also called the Plane of Faerie.
Some are also found in the Outer Planes, particularly the planes of Arborea and the Beastlands. 

Fey include dryads, pixies, and satyrs.