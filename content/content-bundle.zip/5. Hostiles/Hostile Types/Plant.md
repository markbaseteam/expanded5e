**Plants** in this context are vegetable creatures, not ordinary flora. However, non ordinary flora can include static and unconspicous plants that are poisonous.

Most of them are ambulatory, and some are carnivorous.

The quintessential plants are the [[Shambling Mound]] and the [[Treant]]. Fungal creatures such as the [[gas spore]] and the [[myconid]] also fall into this category.