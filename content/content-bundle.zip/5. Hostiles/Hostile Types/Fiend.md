**Fiends** are creatures of wickedness native to the Lower Planes.
A few are the servants of deities, but many more labor under the leadership of archdevils and demon princes.
Evil priests and mages sometimes summon fiends to the material world to do their bidding.
If an evil celestial is a rarity, a good fiend is almost inconceivable.

Fiends include demons, devils, hell hounds, rakshasas, and yugoloths.