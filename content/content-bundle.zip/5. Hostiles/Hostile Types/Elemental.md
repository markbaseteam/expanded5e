**Elementals** are creatures native to the elemental planes.
Some creatures of this type are little more than animate masses of their respective elements, including the creatures simply called elementals.

Others have biological forms infused with elemental energy.
The races of genies, including djinn and efreet, form the most important civilizations on the elemental planes.
Other elemental creatures include azers and [[Invisible]] stalkers.