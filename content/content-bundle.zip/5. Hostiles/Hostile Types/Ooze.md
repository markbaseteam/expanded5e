**Oozes** are gelatinous creatures that rarely have a fixed shape.
They are mostly subterranean, dwelling in caves and dungeons and feeding on refuse, carrion, or creatures unlucky enough to get in their way.

Black puddings and gelatinous cubes are among the most recognizable oozes.