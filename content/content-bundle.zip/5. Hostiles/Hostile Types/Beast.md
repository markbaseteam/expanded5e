**Beasts** are nonhumanoid creatures that are a natural part of the fantasy ecology.
Some of them have magical powers, but most are unintelligent and lack any society or language. 

Beasts include all varieties of ordinary animals, dinosaurs, and giant versions of animals.