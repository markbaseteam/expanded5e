**Celestials** are creatures native to the Upper Planes.
Many of them are the servants of deities, employed as messengers or agents in the mortal realm and throughout the planes.
Celestials are good by nature, so the exceptional celestial who strays from a good alignment is a horrifying rarity.

Celestials include angels, couatls, and pegasi.