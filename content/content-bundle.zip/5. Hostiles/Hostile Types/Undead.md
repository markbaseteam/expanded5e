**Undead** are once-living creatures brought to a horrifying state of undeath through the practice of necromantic magic or some unholy curse. 

Undead include walking corpses, such as vampires and zombies, as well as bodiless spirits, such as ghosts and specters.