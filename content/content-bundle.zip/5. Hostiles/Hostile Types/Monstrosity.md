**Monstrosities** are monsters in the strictest sense—frightening creatures that are not ordinary, not truly natural, and almost never benign. 
Some are the results of magical experimentation gone awry (such as [[Owlbear]]s), and others are the product of terrible curses (including [[Minotaur]]s and [[yuan-ti]]).

They defy categorization, and in some sense serve as a catch-all category for creatures that don't fit into any other type.