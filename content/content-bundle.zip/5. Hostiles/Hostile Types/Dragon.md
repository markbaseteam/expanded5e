**Dragons** are large reptilian creatures of ancient origin and tremendous power.
True dragons, including the good metallic dragons and the evil chromatic dragons, are highly intelligent and have innate magic. 
Also in this category are creatures distantly related to true dragons, but less powerful, less intelligent, and less magical, such as wyverns and pseudodragons.