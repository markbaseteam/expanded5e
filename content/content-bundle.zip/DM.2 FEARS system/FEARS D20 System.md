
The world of [[Eimhin]] uses the custom rule system known as Fifth Edition Advance Rules System (F.E.A.R.S) d20 system, this is branched off from the Standard 5th Edition published by Wizards of the Coast. It is completely backwards compatible with DnD 5th edition.

However, the F.E.A.R.S systems is made to ensure there is more flexibility in the moment with a plaeyrs characters, stategic choices having consquences and to enhance the group role playing mechanisms. Below is some of the changes that are made to enhance 5th edition.

# Features of FEARS 
## New Terminology
To ensure there is a limited conflict with the 5E IP certain terminology has been changed

**(KoL)** Keeper of Lore is used interchangably with DM, focusing more than the gamemaster is keeping the lore and helping with the Lore of the world compared to specifically forcused around Dungeons. 


## For players
### Expanded Class Systems
The classes still have all classes within the 5th edition rules set and all subclasses are backwards capatible. However, the classes have been expanded to include a few additional classes and a lot of subclasses. This is to allow complex flexibility to the player. 

#### New classes
- Alchemist (seperate from the Artificer subclass)
- Craftsman
- Investigator
- Magnus also known as a SpellSword
- Rune Keeper
- Shaman
- Warden
- Witch

### Forced leveling up
A player can force a level up when wishing to multi-class, however, they must explain the the KoL the reason for multiclassing, how its tied into the current situation that the players or party find themselves in. If the KoP agrees the following happens, remember this choice is permanent;

1. Can not be done at Level 20 or before Level 3 and can not make the player more than 1 level higher than the average party member.
2.  Player immediately levels us in the new class and heals 1 Hit Dice of the new class and gains an additional 2 levels of the classes Hit Dice of temporary hit points. 
3. Picks the subclass of the new class and get immediately access to the Subclasses abilities up to Level 3 for 10 - players profieceny rounds of combat or minutes out of combat. After this time they revert back to only having 1 level in the new class. If choosing this subclass means a comittment to a oath, bond, patron they must maintain this after reverting or suffer consquences.
4. While having access to the new class the first attack is at [[Advantage]] as would be treated as a suprised attack. 
5. Gain 1 level of [[Exhaustion]] when they revert to the single level of the class.
6. Once done can not be done again till after 1 year or if the party levels up.

Examples of using this system, would be the following;
- Middle of combat close to death or falling to 0HP you reach out and pledge your alliance to a Patron to gain 1 level of Warlock and keep fighting, reaching out to the Fiend or Grasping a blade for the HexBlade for example
- Screaming to the Gods or Nature itself to help protect or heal, dedicating yourself to follow the rules of who you scream out to and gaining a level in Druid or Cleric. 
- Pledging an Oath to protect or revenge or kill gaining a level in Paladin.
- Being hurt and dedicating yourself to know everything about the monster or humanoid who hurt you, making them your favoured enemy and gaining a level in Ranger.
- Running out of spellslots and in a rage picking up a blade and launching yourself forward, gaining a level in Barbarian.

A player can still choose to multiclass in other ways without suffering the buffs or conquences of forcing leveling up. Force level up could ignore class pre-requists but this is up to the KoL.

### Cursed Classes 
There are also a series of "Cursed Classes" that can be unlocked, usually via either being cursed, dedicating yourself to turning into one of these classes or disease. These level up like normal classes. 

- When a player gains a level in either thier class prior to this path they gain a level in both classes. 
- This keeps until level 10 then the player looses one of their orignal classes level for each level of the cursed class. 

#### Known Cursed Classes
The following are the known Cursed classes at the moment of time. Some tranformations have numerous paths such as turning into a Fey or a Hag depending choices;

- Ceremorph/ Abberrant Horror (transformation)
- Fiend/ Death Knight (transformation)
- Evolutionist (Self committed)
- Revenant (tranformation)
- Lycanthrope (transformation)
- Vampire (transformation)
- Fey/ Covenborn (transformation)
- Bound spirit (Death)
- Lich (transformation)
- Specter (tranformation)
- Primodial/ Floraspawn (transformation)

It is rumoured that there may be a way to transform into a Seraph. However, how much truth is in this is unknown.

### Soul-twisted
A character can become Soul-twisted when travelling through an Arc Portal to a world managed by FEARSd20, during the travel their soul may violently collide with another of the same race but different Homeworld of their own. Now being a creature of twin background they can encounter flashbacks to another place, time or be driven by desires, fears or regrets not of their own or potentially not even to their knowledge. 

Migrations or escapes from a dying realm depending on your view on the matter happen between one realm and another, The Crack has created an unprecedented situation one that even those older the realms themselves have never seen. A situation where numerous worlds to the same new realm at the same time.

When a character becomes Soul-twisted, the character rolls on the homeworld table found below. Up to the KoL the character may have access to their characters classes subclass of the other homeworld, feats or spells. 

The Soul-twisted can also ask for knowledge from their twisted soul's homeworld when making Skill checks such as religion, medicine, insight or history. Or to overcome the bias or fears of an NPC from the same homeworld as their twisted soul. 

However, this comes at a cost to their sanity and health with a saving throw of type the skill relates to (Intelligence for History, Wisdom for Medicine) and a DR relating to the information sought. If the saving throw fails a penalty of 1d8+ ability score modifier for the related skill (increased by 1d8 every 3 levels)

### Twin Subclassing
If a character is Soul-twisted, upon level 3 the KoL reveals the second sub-class the character has. The vast majority of soul-twisted will have a sub-class from the first class they leveled to level 3.

If it up to the KoL if they wish to allow twin subclassing from another class. There maybe a rational behind this just ensure you discuss this with your players before this happens. As it has the possibility to completely change the playstyle in a direction the player did not wish for thier character.

Also let your players challenge your choice of make recommendations allowing their character growth to go directions unexpected to the KoL.

### Luck (Blessed and Cursed)
Luck, good and bad, is real and consquential. Granting buffs and debuffs to players but is reset on a [[Short rest]]. So parties must consider if keeping a players good luck up when a player is close to suffering a debuff from bad luck and vice versa is best for the party. 

When a PC rolls 3 Nat 1's without a rest. The player has [[(Table) Cursed Luck]], this gets rerolled again at the fifth Nat 1 and every third Nat 1 after. 

When a PC rolls 3 Nat 20's without a rest. The player is [[(Table) Blessed Luck]] - this gets rerolled again on the fifth Nat20 and every third Nat 20 afterwards.

Only 1 Nat 20 or Nat 1 per turn in combat counts towards the above. 

## Magic Changes
### Spellcasting Criticals
On a NAT20 for spellcasting the player criticals like any attack and causes the same damage increase. However, due to the stress of forcing magic beyond is normal boundaries the players must also roll on the school of magics wild magic table. Every enemy within sight (60ft) must roll a Wisdom saving throw or be [[Frightened]] for 3 rounds. 

Creating some spectular and unique moments with magic. The increase of damage comes at the cost. Random and striking fear at the sight of the display of magic. 

Roll a D20 on a Nat20 the land becomes an [[Arcane Rift]] for the school! 1 month per level of the spell with anything over level 6 being permenant. 

### Overcharging Spells 
**Overcharging Spells** You can attempt to cast a spell without requiring a spell slot by expending a number of Hit Dice equal to the level of the spell. When you do, make a Spell Check. The DC equals 10 + the level of the spell. If you match the DC it is still classes as as success but the player must roll the number of times equal to the level of the spell on the primary class wild magic table.

**Success:** You successfully cast the spell.

**Failure:** The spell fails and you take Force damage equal to the Hit Dice expended. This damage cannot be reduced in any way. 

Whether the spellcasting is successful or fails, you immediately suffer 1 level of [[Exhaustion]]

### Living and Killable Spells
Spells exist in an original form. Thousands of years ago, mages began to create the first spells, even before discovering the existence of the fabric of magic. After much research and practice, the mage casts a spell for the first time. 

At that moment two things happen: 

1. The effect of the spell materializes in our plane; and the original version of the spell materializes in the world. When that castercasts this spell again, the weave of magic creates a copy of the same original spell to materialize its effect. And the same thing happens when another wizard copies the spell in his book to cast it, and this knowledge is passed from wizard to wizard for centuries or millennia.
2. The original version of each spell physically manifests and lives on our plane. These spells are usually found inunreachable areas of the world. A sleeping living spell has a container where it spends the millennia. These are very much prized as treasure my magic users or being of magics, such as Cloud Giants, Dragons or Genies.

There is only one original of each spell per world, and if it were to disappear, the spell could not be cast again. The notes that are in the books of hundreds of magicians in the world would be useless, because they would not have an original from which to take their effect. Someone would have to repeat the creation process exactly, which is nearly impossible.

If you have the container of the spell you can use it as a magic conduit and cast the spell as an automatic crit once per long rest but with no chance of creating an Arcane Rift, you do need to roll on the wild magic table. However, you must roll an arcana check vs DC 10+spell level. On a 1 the container breaks and that spell can not longer be used by anyone. 

If you fail a living version of the spell mainfests out of the bottle. If in combat, it will attack anyone at random, it must be reduced to 0 and put back in its Phylactery. If not in combat, and the spell is not a damange spell it can be reasoned with an convinced to go back into its container. 

You can smash a spell phylactery and choose to kill the spell. This removes the spell from the world. This will have consquences unforseen.

### Discoverable Magic
As many spells have been forgotten, than are known to the spellcasters of this plane. However, these can be found in the oddest places. From treasure troves, to arcane rifts, to wild magic zones, and even on never faces monsters.

If a character finds an unknown Scroll, Writing or Phylactery, they can study it and learn the spell. Upon first cast, if the character does not concentrate on ensure it doesnt escape. It will disappear. 

If it is a scribble of a spell that is forgotten, roll an arcana, insight or even performance (spells often have methods that are visible to be copied if they words are not fully understood) if passed. The character can learn the spell. the KoL can decide if they player gets [[Advantage]] if the spell it related to the background/race etc of the character.

There are dedicated spell hunters, who desire nothing more than finding "new" spell. How else does someone get a doctrate in a magical school? You call make a fortune selling your knowledge to the highest bidder.

If the magic is first encounted via a monster. The monster must be observed to cast the spell, then the spell must be remembered (DC = 10+level of the spell) vs the Passive investigation or a player/s. The monster must be harvested and studied (on long rest) and a suitable check undertaken vs the DC listed above.

## Combat Changes
Combat is aimed to be more precise and the ability to work with your party to create strings of attacks that help or hinder is encouraged. 

### Interactive Actions
This is a new action type, on each round a player has an additional internactive actions. This action is aimed to allow on a PC’s turn, they can use their Interaction to perform 1 Check to gain extra information or interact with the world around them. 

This can include loading a weapon, picking up a weapon, asking to observe if they can tell what an enemy is going to take or challenge an enemy in a check. 

This does not replace free actions, just encourages interaction with the environement. 

### Buying bonus actions
Removing 30ft of movement and making the player [[Disadvantage]] against [[Opportunity attacks]] the player can swop 30ft of movement for an additional bonus action. Allowing different combinations and stack confitions in attacks. 

### Glancing Blows
If a creature makes an Attack against you and EXACTLY hits your AC, then the Attack hits (as usual) but it’s a Glancing Blow and it deals half damage instead. If you are using any effects or attack modifier seperate from your attack (slayers prey, melee spells etc, smite) these must be rolled as seperate attacks but will if they match the AC they will deal full damage.

If the creature is two sizes bigger than you. Make a Athletics or Acrobatics check or be pushed 5ft away from the creature. Nat 1, you armor takes damage and drops by 1. 

***Example:*** Your AC is 18. If a creature’s Attack totals below 18, they miss and deal no damage. If a creature’s Attack totals above 18, they hit and deal full damage. However, if a creature’s Attack totals EXACTLY 18, they hit but only deal half damage. Keep in mind that this rule will decrease the amount of damage creatures take. Normally, exactly hitting a target’s AC would deal full damage, so this does make creatures last longer in combat. 

### Weapon Maneuvers
When a player has profiency with a weapon they can take two weapon attacks and attempt a weapon maneuver. This unlocks [[Special Attacks]] abilities with the weapons.