# Crafting Potions

The term “potion” is generally used to describe a variety of mixtures, infusions, elixirs, and distillations that are crafted to produce a medicinal, magical, or in the case of poisons, adverse effects. It is necessarily a very broad definition because there is such a wide variety of effects that one can create.

Since there is such a diversity of potions, there are many ways to craft them, and in fact some of the more advanced or complicated potions might employ more than one of these in their production. 

Listed below are the six most common processes used for producing potions:

## Alchemical Transmutation 
While alchemy is a general term that utilizes many of these processes to achieve the proper result, alchemical transmutation is a very specific process where by various components are transmuted into something entirely new. 

The most well known and elusive alchemical transmutation is the conversion of base metals into gold, but a similar process can be used to turn mundane items into a potent magical brew.

The ingredients used in an alchemical transmutation potion are most often selected for symbolic magical properties rather than any inherent natural property they possess. 

For example, a potion to improve vision might include a small glass lens and the eye of an eagle. Through a complex alchemical process, these symbolic items imbue the potion with the properties these items symbolize. The items are usually consumed in the process, and no signs remain in the final potion. 

## Brewing & Fermentation 
The arts of brewing and fermentation are as old as the elves, and have been used in the preparation of food and drink for millennia. The process of brewing and fermenting potions is not that much different from alchemy, except that the ingredients used have either medicinal or magical properties that are activated through a metabolic process converting sugars into acids, gases and/or alcohol. 

## Distillation 
Distilling is the process of heating a substance to produce a vapor, which is then cooled and condensed, in order to purify, concentrate, or extract components from the substance. 

## Infusion 
Infusing is the process of extracting compounds from plant material in a solvent such as water, oil or alcohol, by allowing the material to remain suspended in the solvent over time (a process often called steeping). 

## Magical Craft 
The most potent of potions are those produced by magical craft and must be produced by, or in partnership with, the appropriate spellcaster — arcane or divine. To create a magical potion, a base liquid must be prepared beforehand. This is often done through alchemical means, utilizing specific symbolic elements or material components required for the desired spell effect.

Once the base liquid is ready, the desired spell must be cast into the liquid, just as if the spell were being cast normally. Great care must be taken, because if there is any incompatibility between the base liquid and the spell, the results will be catastrophic.

A small number of very skilled alchemists can produce magically crafted potions without having a spellcaster present by using a scroll or magic item. These individuals are rare, and the risk is much higher, so more often than not, it is simply easier to pay a caster for their time.