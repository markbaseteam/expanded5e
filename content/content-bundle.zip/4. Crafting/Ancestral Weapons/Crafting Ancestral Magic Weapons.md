## Crafting Ancestral Magic Weapons

You can use [[Spirit points]] to allow characters to craft magic weapons. These magical weapons do not earn [[Spirit points]] after being created, and require no special attunement rules beyond those of the standard attunement rules found in the Player’s Handbook. Any item that is very rare or legendary, or that has a limited upgrade, requires attunement.

To craft a magic item, the player must pay a cost, as well as spend a period of time, both shown in the below table, in order to craft the item. The cost covers both magical and mundane materials. In order to embed a spell into a weapon, the player needs access to a spellcaster who has has the ability to cast that spell, and who must spend a number of days with the weapon equal to 1 + the spell level.

| Min Level | Rarity    | Number of Spirit Points | Cost per Spirit Point | Time per Spirit Point |
|----------|-----------|-------------------------|-----------------------|-----------------------|
| 1+       | Uncommon  | 1-4                     | 200 gp                | 2 days                |
| 5+       | Rare      | 5-9                     | 500 gp                | 3 days                |
| 10+      | Very Rare | 10-15                   | 55,000 gp             | 4 days                |
| 16+      | Legendary | 16-25                   | 20,000 gp             | 1 week                |


To create such items a Dungeon Master may deem that a character needs to be proficient with Smith’s tools, Woodcarver’s tools or similar.  

Unique Reagents Crafting a magical weapon should never be an easy endeavor. Oftentimes it is a great opportunity for a player driven quest. By requiring a unique reagent, such as the claw of a red dragon or a medusa's eye, the characters will drive the campaign forward allowing for additional motivations to add to determine their characters actions.

Gitzla is a goblin merchant who specialises in magical curiosities. He mostly tricks people into thinking they are buying something and palming them a fake. He has a ‘Lukky Coin’ that can be 
found in Treasures of the Mad Mage!

## Route to unlocking

Crafted weapons can be unlocked and their weapons spirits enabled, however, this can only be happened after;
1. Number of generations passed (Measured in average Human lifespans)
2. Player fulfilling one of the [[(Table) Types of Feat of Legend]] of the weapons, reducing the generations by what is deemed suitable by the DM.

## Example Crafted items
### Dirk of the twin fangs 
*Weapon (dagger), legendary, requires attunement* 
**Upgrades;** 
*23 spirit points:* [[Enhanced Weapon (level 3)]] - 10 spirit points, [[Overpower (Poisonous)]] - 2 spirit points, [[Venomous]] - 7 spirit points, and [[Jarring]] (level 2) - 4 spirit points.
**Cost to craft:** 460,000 gp 
**Time to craft:** 23 weeks

Deep in the Underdark, in Menzoberranzan, the drow elf Ulkina Eldraor disappeared one day. She returned with a dagger of fine craftmanship, with snake venom coursing through the blade itself. No-one knows what price she paid for such an item of nightmares.

You have a +3 bonus to attack and damage rolls made with this magic weapon, and any enemy that you make a weapon attack against with this weapon cannot make attacks of opportunity against you until the beginning of your next turn.

If the d20 roll for an attack made with this weapon is a 19 or 20, you can force a creature that suffers damage from this weapon to make a DC14 Constitution saving throw, in addition to any damage caused. On a failed save, it gains the poisoned condition. A creature can repeat the saving throw at the end of each of its turns, ending the effect on it on a success.

A creature damaged by this weapon must make a DC15 Constitution save at the start of each of their turns for 1 minute. On a fail they suffer 2d6 poison damage, and if they pass this effect ends. A creature can only be affected by this effect once per day.

## The Sunstaff 
*Weapon (quarterstaff), very rare, requires attunement* 
**Upgrades;
12 spirit points:** [[Magus (level 1)]] - 5 spirit points, [[Spell Storing (level 3 - daylight)]] - 6 spirit points, [[Bully]] - 1 spirit point, and [[Guiding Weapon]] - 1 spirit point 
**Cost to craft:** 60,000 gp 
**Time to craft:** 48 days

Glowing proudly with a golden light, this weapon was crafted by the smiths of the sun worshipping Iliathoran tribe. It is now wielded by the ruling high priestess.

Whilst holding this weapon you have a +1 bonus to spell attack rolls and a +1 bonus to AC. You gain advantage on intimidation checks when the target can see you and you are holding this weapon.

The weapon sheds bright golden light in a 15-foot radius, and dimlight for an additional 15-foot.  You can use an action to cast *[[Daylight (Spell)]]* from the weapon. You must complete a long rest before you can use this ability again. 

## Gitzla’s pokey Stabb
*Weapon (shortsword), rare, requires attunement by a rogue*
**Upgrades,** 
*8 spirit points*: [[Enhanced Weapon (level 1)]] - 3 spirit points, [[Blindside (level 1)]] - 4 spirit points, and [[Quick]] - 1 spirit point. 
**Cost to craft:** 4,000 gp
**Time to craft:** 24 days

Gitzla’s emporium of rare and unknown curiosities in the Undermountain often attracts light fingers. Gitzla commissioned his pokey stabba to ensure his goods don’t wander without his knowledge.

You have a +1 bonus to attack and damage rolls made with this magic weapon, and you increase the damage of your sneak attacks made by this weapon by d6.

You have advantage on initiative rolls.