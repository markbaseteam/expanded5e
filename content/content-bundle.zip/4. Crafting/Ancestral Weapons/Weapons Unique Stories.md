## Weapons Unique Stories

Every [[Ancestral weapons]] holds a unique story. These weapons have been used in great battles, fought monstrous creatures, and been the envy of kings. You can create the history for your weapon, or you can instead roll on the tables provided below to randomly create a background for the weapon.

This section details the age of the weapon, measured in generations. Ancestral weapons exist of many ages, from being handed down a single generation, to being older than many races.

First you should determine how many generations the weapon has been in existence, followed by how many feats of legend the weapon has been involved in. 

These feats of legend reveal some of the story into how the weapon became so powerful. It may have been involved in the Blood Wars, could have delivered the final blow to a tyrannical dragon, or have been blessed by a god.

The rules and tables presented here are shown only as a guideline for you to pick and choose from as you wish. Feel free to add, embellish, or alter to make the weapon as unique as your character.
In order to create a background and history of the weapon, roll on the below tables.

1. [[(Table) Craftmanship Race]]
2. [[(Table) Number of Generations Since Created (Race Specific)]]
3. [[(Table) Number of Feats of Legend]]
4. [[(Table) Weapons Identifying Feature]]

Once done decide the [[Rarity of an ancestral weapons]], all the above must be recorded against the weapon. If you wish to now craft the weapon [[Crafting Ancestral Magic Weapons]]





