Many ancestral weapons have small, subtle effects that add character to them. An ancestral weapon can start with these, or unlock them as more of their gifts are earnt. 

There are two types of properties represented in this chapter. However, all Ancestral weapons are created following the  [[Creating Sentient Magic]] rules but does not need ability score, unless the spirit is manifested.

Ancestral Traits are small characteristics built up over the life of the weapon found [[(Table) Ancestral Traits]], whilst Ancestral Personalities reveal the domimant personalities amongst the fragments of the ancestoral spirits that are held within the weapon, found [[(Table) Ancestral Personalities]]

When making that a character will sense when performing certain actions that align with, or against, the ancestral personality is important, as going against could lead to [[Ancestoral Weapon Failure]]

A weapon can have either of the properties presented, one of each property, or neither property. A DM, or a player working with their DM, can also create a history fitting to the weapon and the Ancestral Traits can be supplemented by the Minor Property table on page 142 of the Dungeon Master’s Guide.

To determine an Ancestral Trait or Ancestral Personality, roll on the tables presented below.

1. [[(Table) Ancestral Traits]]
2. [[(Table) Ancestral Personalities]]