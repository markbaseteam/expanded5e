### Creating Sentient Magic Items

When you decide to make a [[Sentient Magic Item]], you create the item's persona in the same way you would create an NPC, with a few exceptions described here.

#### Abilities

A sentient magic item has Intelligence, Wisdom, and Charisma scores. You can choose the item's abilities or determine them randomly. To determine them randomly, roll 4d6 for each one, dropping the lowest roll and totaling the rest.

#### Communication

A sentient item has some ability to communicate, either by sharing its emotions, broadcasting its thoughts telepathically, or speaking aloud. You can choose how it communicates or roll on the following table.
[[(Table) Sentient Magic Items - Communication]]

#### Senses

With sentience comes awareness. A sentient item can perceive its surroundings out to a limited range. You can choose its senses or roll on the following table.
[[(Table) Sentient Magic Items (Senses)]]

#### Alignment

A sentient magic item has an alignment. Its creator or nature might suggest an alignment. If not, you can pick an alignment or roll on the following table.

[[(Table) Sentient Magic Items (Alignment)]]
#### Special Purpose

You can give a sentient item an objective it pursues, perhaps to the exclusion of all else. As long as the wielder's use of the item aligns with that special purpose, the item remains cooperative. Deviating from this course might cause conflict between the wielder and the item, and could even cause the item to prevent the use of its activated properties. You can pick a special purpose or roll on the following table.
[[(Table) Sentient Magic Items (Special Purpose)]]

#### Conflict

A sentient item has a will of its own, shaped by its personality and alignment. If its wielder acts in a manner opposed to the item's alignment or purpose, conflict can arise. When such a conflict occurs, the item makes a Charisma check contested by the wielder's Charisma check. If the item wins the contest, it makes one or more of the following demands:
[[(Table) Sentient Magic Item (Conflict)]]