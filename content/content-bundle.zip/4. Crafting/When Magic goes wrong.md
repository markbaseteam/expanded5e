
Source: [[PDFs/When Magic goes wrong.pdf]]

# Chapter 1: What is a Quirk?

This chapter presents what you need to knowto create quirks for the magic items that youare ready to introduce in your campaign.

# What is a Quirk?

A quirk is a slight mishap in the creation of a magic item:the steps are not followed in the proper order, theastrological signs do not bode well, the item’s creator isdisturbed to begin with, the instructions are incomplete, orsomething just plain goes wrong. Any of these results cancause a magical item to behave differently from others justlike it. Not all quirks are bad, however. Some aredetrimental to the item or its user, some are neutral, andsome are even beneficial.When you are about to introduce a new magic item in yourcampaign, roll a d10. On a 10, the item has a quirk.Alternatively, you decide if a magic item has a quirk whenyou see it is fit for your campaign's story.

# Features of a Quirk

Each quirk has its own story and its characteristics. Usethe following steps to create your unique quirk.

Origin of a Quirk What did go wrong? Was it an incomplete ritual? Was the mage too young and inexperienced? Were the components of poor quality? Or maybe did the mage craft a magic item with a quirk on purpose? You can either roll on the table below or choose the origin you find most appropriate.

### Quirks Origin

d12 Origin

1 Simple bad luck 2 A rival of the magic item’s creator somehow

interfered during the craft

3 The creator used an incomplete formula 4 The creator made a mistake while pronouncing the

formula’s words

5 The creator used poor quality components 6 The creator skipped a step in the craft 7 A creature from the far realm interfered during the

craft

8 The magic item was modified by a nearby wild

magic surge

9 The creator didn’t use the components required

10 The creator crafted the item at the wrong time 11 The creator didn’t wait for the correct stellar

alignment

12 The creator did it on purpose

How to Discover a Quirk Some quirks might be evident by simply looking at the magic items, others might be discovered only after a careful examination, while sometimes the owner can realize that the magic item has a quirk only by accident when a specific situation arises. You can either roll on the table below or choose the method for discovering a quirk that you find most appropriate.

### Method to Discover a Quirk

d6Method

1 Immediate 2 Spell 3 Rest 4 Trigger 5 Check 6 Research

## Check

You discover the quirk when you spend 1 minute to investigate the item and you succeed on a DC 15 Intelligence (Arcana) check.

## Immediate 

Either the quirk is immediately evident (e.g.: the magic item shines a strange light, etc.) or you become aware of the quirk at the same moment you touch the magic item.

## Research

While you might be aware of the presence of a quirk, youneed to do some research. For that purpose, you can use the Research downtime activity presented in the Xanathar’s Guide to Everything.

## Rest

You discover the quirk after a short or long rest with themagic item next to you.

## Spell

You discover the quirk only through one or more of these spells:

1. [[Augury]]
2. [[Commune]] 
3. [[Detect Magic]] 
4. [[Identify]] 
5. [[Legend Lore]] 

## Trigger 

The quirk is discovered only when a specific situation arises. For example, you have a magic sword whose quirk is that it doesn’t cause damage to humanoids, and you discover the quirk only the first time you hit a humanoid with an attack with your magic sword.

## How to Dispel a Quirk 

Generally, a quirk is inextricably part of the magic of the item itself. One cannot dispel the quirk without dispelling the magic of the item, thus making it a common normal item. However, if you do like so, 

Chapter 3: 

Quirks and Downtime gives you a new downtime activity to remove a quirk from a magic item. Quirk and Rarity of Magic Items A quirk can sometimes modify the rarity of a magic item. As a rule of thumb, when you assign a quirk to a magic item, lower the rarity of that item by one notch. For example, a magic item that normally is very rare becomes rare with a quirk.

# Chapter 2: Magic Items’ Quirks

This chapter provides tables for quirks foreach type of magic item, alphabeticallylisted. Roll on the tables below or pick up thequirk you like the most.

### “Impossible” Quirks 

Though it is a remote occurrence, it may happen that the quirk you’ve rolled doesn’t fit to a specific item. In that case, roll again on the table.

# Armors

### Quirks for Armors

d20Quirks

1 The armor sheds bright light in a 10-foot radius, even if you cover it. The light is only negated by magical means 2 The armor is incredibly heavy, Add 50% to its total weight and encumbrance 3 The armor is tight-fitting. You must oil it once every week for 10 gp. If you do not do so, while wearing the armor you have disadvantage on any Dexterity checks and saving throws 4 The armor functions normally, but it appears incredibly beaten and battered, no matter what you do to repair it. Under specific circumstances judged by the DM, you can have disadvantage on Charisma checks 5 The armor has an “Achilles’ Heel”. Each time you are hit by an attack while wearing this armor, roll a d20. On a 1, the attack has hit the Heel and you take double damage 6 The armor cannot be scratched, stained, or dented 7 The armor has an inherent disruption of magic. While wearing this armor, you can’t cast spells 8 The armor does not provide protection if a clothing or a covering is worn over it 9 The armor is a superconductor of heat and electricity. While wearing this armor you are vulnerable to fire and lightning damage 10 The armor’s magical protection doesn’t function against 1d4 types of creatures randomly chosen 11 The armor is particularly effective against 1d4 types of creatures. These creatures have disadvantage on attack rolls against you while you are wearing this armor 12 The armor emanates a thin but visible aura. Creatures that aren’t blinded have advantage on Wisdom (Perception) check to notice you, even if you are behind total cover

d20Quirks

13 The armor weighs only 25% of the normal weight for that type of armor 14 The armor has complicated straps and is hard to punt on and remove. Consequently, the time required to put on and take off the armor is increased by 10 minutes 15 The armor is incredibly silent. While you wear it, you have advantage on Dexterity (Stealth) checks made to hide. 16 The armor attracts wandering monsters. While wearing this armor during travel or an exploration of a dangerous area (like a dungeon, a cave, etc.) the chance to encounter random monsters is doubled 17 The armor attracts attacks. While wearing this armor during a combat, you are always chosen as the target of attacks by creatures that are hostile t o you over other available targets 18 The armor is resistant to fire. It cannot be burned or melted by normal or magical fire 19 The armor is attuned to a place of special magical radiance, chosen by the DM. If the armor is not exposed to this place once every 30 days, its magic is lost 20 The armor’s magic doesn’t function in darkness

# Potions

### Quirks for Potions

d20Quirks

1 When you drink this potion, you glow and shed bright light in a 10-foot radius centered on you as long as the potion is in effect, or 10 minutes if no duration is given 2 When you drink this potion, your skin turns a random color for 1d10 minutes 3 When you drink this potion, you cannot speak nor casts spells with verbal components until you finish a long rest 4 When you drink this potion, your senses sharpen. You gain the effects of the Alert feat while the potion is in effect or for 1 hour if no duration is given 5 When you drink this potion, you are deafened due to buzzing or ringing in your ears until you finish a long rest 6 When you drink this potion, you are blinded as long as the potion is in effect, or 10 minutes if no duration is given 7 When you drink this potion, you gain truesight for 10 minutes. If you already have truesight, you lose it for the same amount of time 8 The potion has no effects on humanoids 9 When you drink this potion, you become intoxicated. You are poisoned as long as the potion is in effect, or 1 hour if no duration is given 10 When you drink this potion, you experience slight disorientation. You gain disadvantage on each of your attack rolls, saving throws, and ability checks for 1 minute. During that period, attack rolls against you are made with advantage 11 When you drink this potion, you become drowsy. At the start of your next turn, make a DC 15 Constitution saving throw. On a failed save, you fall asleep for 1d10 minutes. While sleeping, you wake up if you take at least 1 damage 12 The potion is phosphorescent and glows in the dark as per the 

faerie fire spell 13 The potion is found in powdered form. Water must be added to the powder for the potion to be effective 14 The potion is stronger than normal. Its effects and duration are 200% (double) of a normal potion of the same type 15 The potion evaporates before you drink it if you don’t succeed on a DC 15 Dexterity (Sleight of Hand) check 16 The potion is nauseating to drink. When you drink this potion, you must make a DC 15 Constitution saving throw. On a failed save, you puke the liquid, and the potion has no effect 17 The potion is unstable. Each time you take at least 10 damage, roll a d20. On a 1, the potion explodes. Each creature within 10 feet of you must make a DC 15 Dexterity saving throw, taking 10 (3d6) fire damage on a failed save, or half as much damage on a successful one

d20Quirks

18 When you drink this potion, you become extremely verbose and talk incessantly as long as the potion is in effect or for 1 hour if no duration is given. During this time, you have disadvantage on any Dexterity (Stealth) check 19 The potion is unstable. When you drink this potion, roll an effect from the Wild Magic surge table of the Sorcerer class in the PHB. The potion has the normal effect 20 When you drink this potion, the potion has the normal effect, but you become addicted. You suffer a long-term madness. As long as you suffer that madness, you are compelled to drink a potion of the same type at least once a week. If you do not do so, you have disadvantage on each of your checks and saving throws until you drink a potion of the same type. A greater restoration spell or similar magic removes the madness

# Rings

### Quirks for Rings

d20Quirks

1 The ring works only in sunlight or bright light 2 The ring works only in dim light or darkness 3 The ring doesn’t work in underground areas 4 The ring works only if it is the only magic item you are attuned to 5 The ring works only after 24 hours you get attuned to it 6 The ring works erratically. At each dawn roll a d20. On a 1, the ring doesn’t work until the next dawn 7 The first time you attune to this ring, it grafts to your finger. You can’t remove it nor end attunement to it. The only known means are a wish spell or removing the finger from your body 8 When its powers are in effect, the ring glows and you are under the effect of a faerie fire spell 9 The ring doesn’t work when it is within 30 feet of another magical ring 10 When you are attuned to this ring, you are colorblind and can only see in black and white 11 When you are attuned to this ring, you experience terrible nightmares while sleeping or resting, and you recover hit points only up to half of your maximum from a long rest 12 When you are attuned to this ring, a humming is heard by creatures within 10 feet of you 13 The ring doesn’t work if you are wearing a medium or heavy armor 14 The ring is specially enchanted and cannot be destroyed by any means 15 You cannot attune to this ring if you are attuned to another magical ring 16 You must polish the ring with a wax worth 5 gp. If you do not do so, the ring doesn’t work until the next dawn 17 The ring is unusually heavy. While you are attuned to this ring, your speed is reduced by 5 feet 18 The ring causes you to hear strange voices in your head. While you are attuned to this ring, you gain disadvantage on your Wisdom and Intelligence checks and saving throws 19 When you are attuned to this ring, it becomes invisible and it can be detected only by creatures with truesight or similar magic 20 The ring is more powerful than normal. If it has charges, it always regains all spent charges daily at dawn

# Rods, Staves, and Wands

### Quirks for Rods, Staves, and Wands

d20Quirks

1 The item works only in sunlight or bright light 2 The item works only in dim light or darkness 3 The item doesn’t work in underground areas 4 The item works only if it is the only magic item you are attuned to

d20Quirks

5 The item is inefficient. It regains only 1 spent charge daily at dawn 6 The item causes you 1d4 point of force damage each time you use its powers 7 The item doesn’t work if you wear gloves, gauntlets or if your hands are covered 8 When you use this item, you glow and are under the effect of a faerie fire spell 9 The item is unstable. When you try to activate or use its magical properties roll a d20. On a 1, the item doesn’t work 10 The item is difficult to activate. To activate its powers, you must hold your concentration (as per spells) until the end of the round, when the item’s effects finally take place 11 The item doesn’t work in environments warmer than normal human body temperature 12 The item tends to overload. After you have used its powers twice, it doesn’t work until the next dawn no matter how many charges remain 13 The item doesn’t work underwater 14 The item is activated by any creature within 30 feet of it that succeeds on a DC 15 Intelligence (Arcana) check, even by those not attuned to the item. If a creature fails the check, it can’t try another check for 24 hours 15 The item has an extra command word that allows it to shrink to half its regular size or return to norma l 16 Your item is made of metal and is magnetic. It is attracted by any large concentration of metal of at least 30 pounds 17 The item seems attracted by you. Any check to grab the item from your grasp is made with disadvantage 18 The item doesn’t radiate magic, and it’s not detected by the detect magic spell 19 When you are attuned to this item, it becomes invisible and it can be detected only by creatures with truesight or similar magic 20 The item conducts electricity. While you hold or carry this item, you are vulnerable to lightning damage

# Scrolls

### Quirks for Scrolls

d20Quirks

1 The scroll is old and brittle. When you try to read it,

you must succeed on a DC 15 Intelligence check or you rip the scroll, which is lost before any effect occurs

2 When you read this scroll, you glow. You are under

the effect of a faerie fire spell for 1 minute

3 The scroll is barely legible. When you read this

scroll, roll a d20. On a 1, you can’t read it correctlyand the scroll is lost without any effect

4 The scroll is waterproof, and you can read it

underwater

5 The scroll is extremely long. When you read it, the

scroll’s effects take place, and the start of your nextturn

6 The scroll is written in ancient magical

hieroglyphics. Before reading this scroll, you musttake a week studying it and succeed on a DC 15Intelligence (Arcana) check. If you fail the check,you can try another check when you gain one level

7 The scroll is more powerful than normal. When you

read this scroll, its effects and duration are 200%(double) of a normal scroll of the same type

8 When you read this scroll, you are disoriented by

its magical writings. You are stunned until the endof your next turn

9 The scroll is written improperly. When you read this

scroll roll a d20. The scroll has effect only if youroll a 10 or higher

10 The scroll is specially magicked. You can read it

twice before it vanishes

d20Quirks

11 The scroll is permanently stuck in a magically

strong rolled-up form. You must succeed on a DC15 Strength check to read it

12 The scroll’s writings are hidden by an illusion. You

must succeed on a DC 15 Intelligence checkbefore you read it

13 The scroll is unstable. When you read this scroll,

roll an effect from the Wild Magic surge table ofthe Sorcerer class in the Player's Handbook. The

scroll has the normal effect

14 The scroll is slow to take effect. When you read it,

its effects start at the end of your next turn

15 The scroll is specially treated, and it never takes

damage, nor it can be destroyed

16 The scroll is dust covered. When you read it, you

must succeed on a DC 15 Constitution savingthrow or be choked by the dust. Until you arechoked you cannot speak nor breathe. At the endof each of your next turns, you can make anotherConstitution saving throw, ending the effect onyourself on a success

17 The scroll suffers sunlight. If you try to read it

under sunlight, it crumbles to dust before anyeffect takes place

18 The scroll is written in invisible words. You must

have truesight or use similar magic to read it

19 The scroll is incomplete. When you read this scroll,

you must succeed on a DC 15 Intelligence (Arcana)check to complete it. Otherwise, the scrollvanishes without effect

20 The scroll contains the spirit of its creator. When

you read this scroll, a wraith appears next to you. It

is hostile towards you

# Shields

### Quirks for Shields

d20Quirks

1 The shield sheds bright llight in a 10-foot radius, even if you cover it. The light is only negated by magical means 2 The shield is incredibly heavy, Add 50% to its total weight and encumbrance 3 The shield is very cumbersome. While carrying it, you disadvantage on any Dexterity checks and saving throws 4 The shield functions normally, but it appears incredibly beaten and battered, no matter what you do to repair it. Under specific circumstances judged by the DM, you can have disadvantage on Charisma checks 5 The shield is unusually small but weighs like a normal shield. It grants only half (rounded up) of the bonus normal shield of this type would grant 6 The shield cannot be scratched, stained, or dented 7 The shield has an inherent disruption of magic. While carrying this shield, you can’t cast spells 8 The shield automatically and immediately teleports onto your offhand each time a combat starts. 9 The shield is a superconductor of heat and electricity. While carrying this shield you are vulnerable to fire and lightning damage 10 The shield’s magical protection doesn’t function against 1d4 types of creatures randomly chosen 11 The shield is particularly effective against 1d4 types of creatures. These creatures have disadvantage on attack rolls against you while you are wearing this armor 12 The shield emanates a thin but visible aura. Creatures that aren’t blinded have advantage on Wisdom (Perception) check to notice you, even if you are behind total cover 13 The shield weighs only 25% of the normal weight for that type of shield 14 The shield is unstable. The first time in a turn tha t an attack against you misses while you are carrying this shield, roll a d20. On a 1, magical flames erupt from the shield, causing 1d6 fire damage to any creatures within 5 feet of it 15 The shield is vulnerable to magic. While carrying this shield, you have disadvantage on saving throws against spells or magical abilities that target you.  is incredibly silent. 16 The shield attracts wandering monsters. While you are carrying this armor during travel or an exploration of a dangerous area (like a dungeon, a cave, etc.) the chance to encounter random monsters is doubled 17 The shield attracts attacks. While you are carrying this shield during a combat, you are always chosen as the target of attacks by creatures that are hostil e to you over other available targets 18 The shield is resistant to fire. It cannot be burned or melted by normal or magical fire

d20Quirks

19 The shield is attuned to a place of special magical radiance, chosen by the DM. If the shield is not exposed to this place once every 30 days, its magic is lost 20 The shield’s magic doesn’t function in darkness

# Weapons

### Quirks for Weapons

d20Quirks

1 The weapon is unable to cause damage to 1d4 types of creatures 2 With this weapon, attack rolls against 1d4 types of creatures are made with disadvantage 3 1d4 types of creatures have resistance to this weapon’s damage 4 After a combat, the weapon must be baptized in flame, or it loses its magical properties until it is placed within a fire for at least 1 hour (the weapon isn’t damaged by the fire) 5 The weapon is inefficient. On an initiative check, roll a d20. On a 1, you are compelled to use this magic weapon but you have disadvantage on all your attack rolls until the end of the combat 6 The weapon is very heavy. It is considered to have the heavy and two-handed properties, and it cannot be thrown 7 The weapon conducts electricity. While carrying or holding it, you are vulnerable to lightning damage 8 The weapon cannot be scratched, stained, or dented 9 The weapon appears, beat up, notched, scratched, and dented. No amount of polishing can alter its appearance 10 The weapon’s magic functions only in sunlight or bright light 11 The weapon’s magic functions only in darkness or dim light

12 The weapon cannot be broken by any means short of divine power or an irresistible force (such as having 10 tons of rock dropped on it) 13 The weapon is invisible when drawn or held in combat 14 The weapon is unstable. When you make an attack with this magic weapon, roll a d20. On a 1, magical flames erupt from the weapon causing 1d6 fire damage to you and any creatures within 5 feet of you 15 The weapon shows no magical properties until certain conditions are met (for example the killing of a type of creature) 16 The weapon radiates an evil aura, but it is not evil 17 This weapon has an ego and doesn’t want that you use other weapons. When you make an attack with this weapon, make a DC 15 Charisma saving throw. On a failed save, you are compelled to use this weapon until you finish a long rest. On a successful save you are immune to this effect until you finish a long rest 18 The weapon’s magic doesn’t function underground 19 The weapon has an ego that taunts you. The first time in a turn that you miss an attack made with this weapon, you must succeed on a DC 15 Wisdom saving throw or take 1d4 psychic damage caused by the weapon’s offenses 20 The weapon contains the spirit of its creator. When you carry or hold this weapon and your hit points reach 25% or lower than your maximum, make a DC 15 Charisma saving throw. On a failed save, you are possessed by the spirit for 1 minute. You retain all your abilities and characteristics and you gain the following flaw “I want to get out my anger because I’m trapped in this weapon”. You don’t remember what you do while you are possessed

# Wondrous Items

### Quirks for Wondrous Items

1 The Item has a habit of burying itself in any sack, backpack, or container in which it is carried. When you want to use it, you must find it in the container. Make a DC 15 Intelligence (Investigation) check. On a success, you successfully find the item and you can immediately use it, otherwise, you find the item at the start of your next turn 2 The item must accommodate the owner. The item shows its magical properties only 1d4 days after the attunement 3 The item has the annoying habit of buzzing when you use it. The buzzing is audible to any creature that isn’t deafened within 120 feet of the item. 4 The item works only in sunlight or bright light 5 The item has a finite number of uses. It has 2d10 charges remaining. When you spend the last charge, the item becomes nonmagical 6 The item works only in dim light or darkness 7 The item doesn’t function underground 8 The item is unstable. When you try to activate or use its magical properties roll a d20. On a 1, the item doesn’t work
9 The item is magically buoyant and, unless you hold it or tie it down, it levitates upward of 5 feet at t he end of each of your turn 10 The item causes you to become extremely possessive of it. When you attune to this item, you get the following flaw “I think that everyone wants to steal this item”. A remove curse of greater magic removes the flaw 11 The item has a curse on it. Each day at dawn roll a d20. On a 1, you have disadvantage on all attack rolls, saving throws, and ability checks for that day 12 The item doesn’t function underwater 13 The item needs rest between uses. Once you use its magical properties, you must finish a short or long rest before you can use it again 14 The item cannot be destroyed by any means short of an incredible excess of force (such as a deity), by dropping it into a lava pit, or the like 15 The item doesn’t function if you wear medium or heavy armor 16 The item doesn’t function if you carry a shield 17 The item can be used as an arcane focus 18 The item is inefficient. If it has charges, it regains only 1 spent charge daily at dawn 19 The item has an ego, speaks telepathically with you, and is disobedient. Each time you want to use its powers, you must succeed on a DC 15 Charisma (Persuasion) check. Otherwise, the item doesn’t work, and you can try to use it again on another successful Charisma check at the start of your next turn 20 The item draws energy from its owner. When you finish a long rest, make a DC 15 Constitution saving throw. On a failed save, you gain one level of exhaustion

# Chapter 3: Quirks and Downtime?

The Downtime rules included in the Dungeon Master’s Guide  and Xanathar’s Guide to Everything  could be applied when the characters need to research the nature of a quirk or even its existence or as a result of a failed check while crafting a magic item

Moreover, this chapter introduces a new Downtime Activity: Remove a Quirk. Crafting a Magic Item When a character fails the Intelligence (Arcana) check required by the activity by 1 or 2 points, the DM can rule that the activity has been successful but that the magic item created has a quirk. In that case, roll on the tables presented in Chapter 2 to determine the quirk.

## Research 
As part of the Research Downtime Activity, a character could seek to discover the nature of a quirk or even its existence.

## New Downtime Activity 
If the characters want to remove the quirk from a magic item without dispelling its magical properties, you can use the following new downtime activity.

## Removing a Quirk from a Magic Item

Removing a quirk from a magic item can be a difficult task.The magical properties of the item could be permanentlyruined, making the item nonmagical forever in case offailure.Resources. Removing a quirk from a magic item requires at least one workweek of effort and at least 50 gp in expenses to find the right knowledge and components for the ritual. Spending more time and more money increases your chance of success. Resolution.  A character seeking to remove a quirk from a magic item makes an Intelligence (Arcana) check to determine if the ritual is successful or not. The DC varies accordingly to the rarity of the item, as per the table below i. The character gains a +1 bonus on the check for every workweek beyond the first that is spent seeking the item and a +1 bonus for every additional 50 gp spent on the search up to a maximum bonus of +10. If the check fails by at 5 or more, the magical properties of the item are ruined and the item becomes permanently nonmagical.

Complications. Rituals always attract complications. Something may always go wrong, other wizards might be interested in the item, like thieves. As a rule of thumb, a character has a 10 percent chance of triggering a complication, whether the ritual is successful or not. The Removing a Quirk Complications Table provides examples of what might happen. Removing a Quirk Complications

d4Complication

1 A mage or archwizard looks for the item* 
2 The item is stolen by the party’s enemies* 
3 A cult that considers the magic item a relic hunts you for your blasphemous act 
4 The ritual attracts the interest of an extraplanar creature
