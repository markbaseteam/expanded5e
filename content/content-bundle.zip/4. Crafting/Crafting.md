## Crafting

You can craft nonmagical objects, including adventuring equipment and works of art. You must be proficient with tools related to the object you are trying to create (typically artisan's tools). You might also need access to special materials or locations necessary to create it. For example, someone proficient with smith's tools needs a forge in order to craft a sword or suit of armor.

For every day of downtime you spend crafting, you can craft one or more items with a total market value not exceeding 5 gp, and you must expend raw materials worth half the total market value. If something you want to craft has a market value greater than 5 gp, you make progress every day in 5 gp increments until you reach the market value of the item. For example, a suit of plate armor (market value 1,500 gp) takes 300 days to craft by yourself.

Multiple characters can combine their efforts toward the crafting of a single item, provided that the characters all have proficiency with the requisite tools and are working together in the same place. Each character contributes 5 gp worth of effort for every day spent helping to craft the item. For example, three characters with the requisite tool proficiency and the proper facilities can craft a suit of plate armor in 100 days, at a total cost of 750 gp.

While crafting, you can maintain a modest lifestyle without having to pay 1 gp per day, or a comfortable lifestyle at half the normal cost.

### Crafting Magical Items

#### Quirks
When a magical item is being crafted, for each condition being added to the item roll 1d6. The #GM will roll on the appropriate quirk table. When making an item of a level above the user or without suitable knowledge, proficiency with the item roll with [[Disadvantage]]. If the crafter is of higher-level (quality) and has suitable tools roll with [[Advantage]].

If double 1 are rolled at [[Disadvantage]] then the #GM rolls an additional 1d4 is rolled. At 1 the item is [[(Table) Cursed Luck]] as well as having a quirk. This [[curse]] is unknown to the player. 

### Crafting Ancestral Weapon

Ancestral weapons are very different and are legendary weapons that come from generators of heros passing the weapons down from generation to generation. While the weilder does not need to be a direct blood link, they need it to be given or have some link to the weapon. 

These weapons can be crafted following the [[Crafting Ancestral Magic Weapons]], remember these weapons do not start earning additional spirit points until after the weapons generations to become alive have passed. They also need to have a [[Weapons Unique Stories]] created or started.

