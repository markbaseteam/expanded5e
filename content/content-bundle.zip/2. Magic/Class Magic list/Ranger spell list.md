## Ranger Spells

#### 1st Level

- [[Alarm]]
- [[Animal Friendship]]
- [[Cure Wounds]]
- [[Detect Magic]]
- [[Detect Poison and Disease]]
- [[Fog Cloud]]
- [[Goodberry]]
- [[Hunter's Mark]]
- [[Jump]]
- [[Longstrider]]
- [[Speak with Animals]]
- [[Hunter's Cloak]]

#### 2nd Level

- [[Animal Messenger]]
- [[Barkskin]]
- [[Darkvision (Spell)]]
- [[Find Traps]]
- [[Lesser Restoration]]
- [[Locate Animals or Plants]]
- [[Locate Object]]
- [[Pass without Trace]]
- [[Protection from Poison]]
- [[Silence]]
- [[Spike Growth]]
- [[Spirit of the Stag]]

#### 3rd Level

- [[Conjure Animals]]
- [[Daylight (Spell)]]
- [[Duplicate Potion]]
- [[Nondetection]]
- [[Plant Growth]]
- [[Protection from Energy]]
- [[Speak with Plants]]
- [[Water Breathing]]
- [[Water Walk]]
- [[Wind Wall]]
- [[Viper's Essence]]

#### 4th Level

- [[Conjure Phalanx]]
- [[Conjure Woodland Beings]]
- [[Freedom of Movement]]
- [[Locate Creature]]
- [[Stoneskin]]
- [[Tap Panacea]]

#### 5th Level

- [[Commune with Nature]]
- [[Tree Stride]]
- [[Derecho]]