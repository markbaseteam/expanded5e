## Warlock Spells

#### Cantrips (0 Level)

- [[Amanuensis]]
- [[Chill Touch]]
- [[Eldritch Blast]]
- [[Mage Hand]]
- [[Minor Illusion]]
- [[Poison Spray]]
- [[Prestidigitation]]
- [[Promise]]
- [[True Strike]]
- [[Skin Rot]]

#### 1st Level

- [[Break Spell]]
- [[Charm Person]]
- [[Comprehend Languages]]
- [[Dispel Magics]]
- [[Expeditious Retreat]]
- [[Hellish Rebuke]]
- [[Illusory Script]]
- [[Protection from Evil and Good]]
- [[Unseen Servant]]
- [[Eyes of Xedriff]]

#### 2nd Level

- [[Darkness (Spell)]]
- [[Enthrall]]
- [[Hold Person]]
- [[Invisibility]]
- [[Mirror Image]]
- [[Misty Step]]
- [[Ray of Enfeeblement]]
- [[Shatter]]
- [[Spider Climb]]
- [[Suggestion]]
- [[Volant Darkness]]

#### 3rd Level
- [[Counterspell]]
- [[Dispel Magic]]
- [[Duplicate Potion]]
- [[Fear]]
- [[Fly (spell)]]
- [[Gaseous Form]]
- [[Hypnotic Pattern]]
- [[Magic Circle]]
- [[Major Image]]
- [[Presage]]
- [[Remove Curse]]
- [[Tongues]]
- [[Vampiric Touch]]
- [[Patron's Visage]]

#### 4th Level

- [[Banishment]]
- [[Blight]]
- [[Dimension Door]]
- [[Hallucinatory Terrain]]
- [[Curse of Flesh]]
- [[Reflect Spell]]
- [[Siphon Healing]]

#### 5th Level

- [[Contact Other Plane]]
- [[Dream]]
- [[Hold Monster]]
- [[Scrying]]

#### 6th Level

- [[Circle of Death]]
- [[Conjure Fey]]
- [[Create Undead]]
- [[Eyebite]]
- [[Flesh to Stone]]
- [[Mass Suggestion]]
- [[Spell Disjunction]]
- [[True Seeing]]

#### 7th Level

- [[Etherealness]]
- [[Finger of Death]]
- [[Forcecage]]
- [[Plane Shift]]

#### 8th Level

- [[Demiplane]]
- [[Dominate Monster]]
- [[Feeblemind]]
- [[Loathing Bolt]]
- [[Glibness]]
- [[Power Word Stun]]

#### 9th Level

- [[Astral Projection]]
- [[Foresight]]
- [[Imprisonment]]
- [[Power Word Kill]]
- [[Unweave]]
- [[True Polymorph]]