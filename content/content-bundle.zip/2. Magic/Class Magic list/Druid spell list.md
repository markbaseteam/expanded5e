## Druid Spells

#### Cantrips (0 Level)

- [[Druidcraft]]
- [[Guidance]]
- [[Identify Poison and Disease]]
- [[Mending]]
- [[Poison Spray]]
- [[Produce Flame]]
- [[Resistance]]
- [[Shillelagh]]
- [[Slow Poison]]
- [[Verdant Burst]]

#### 1st Level

- [[Animal Friendship]]
- [[Charm Person]]
- [[Create or Destroy Water]]
- [[Cure Wounds]]
- [[Detect Magic]]
- [[Detect Poison and Disease]]
- [[Dispel Magics]]
- [[Entangle]]
- [[Faerie Fire]]
- [[Fog Cloud]]
- [[Goodberry]]
- [[Healing Word]]
- [[Jump]]
- [[Longstrider]]
- [[Purify Food and Drink]]
- [[Speak with Animals]]
- [[Thunderwave]]
- [[Underweller's Hide]]

#### 2nd Level

- [[Animal Messenger]]
- [[Barkskin]]
- [[Darkvision (Spell)]]
- [[Enhance Ability]]
- [[Find Traps]]
- [[Flame Blade]]
- [[Flaming Sphere]]
- [[Gust of Wind]]
- [[Heat Metal]]
- [[Hold Person]]
- [[Lesser Restoration]]
- [[Locate Animals or Plants]]
- [[Locate Object]]
- [[Moonbeam]]
- [[Pass without Trace]]
- [[Protection from Poison]]
- [[Spike Growth]]
- [[Fungal Barricade]]

#### 3rd Level

- [[Call Lightning]]
- [[Conjure Animals]]
- [[Daylight (Spell)]]
- [[Dispel Magic]]
- [[Duplicate Potion]]
- [[Meld into Stone]]
- [[Plant Growth]]
- [[Protection from Energy]]
- [[Sleet Storm]]
- [[Speak with Plants]]
- [[Water Breathing]]
- [[Water Walk]]
- [[Wind Wall]]
- [[Coil Thorn]]

#### 4th Level

- [[Blight]]
- [[Confusion]]
- [[Conjure Minor Elementals]]
- [[Conjure Woodland Beings]]
- [[Control Water]]
- [[Dominate Beast]]
- [[Freedom of Movement]]
- [[Giant Insect]]
- [[Hallucinatory Terrain]]
- [[Ice Storm]]
- [[Locate Creature]]
- [[Polymorph]]
- [[Promise]]
- [[Stone Shape]]
- [[Stoneskin]]
- [[Wall of Fire]]
- [[Ancient Guise]]

#### 5th Level

- [[Antilife Shell]]
- [[Assets/Generated/Awaken]]
- [[Commune with Nature]]
- [[Conjure Elemental]]
- [[Contagion]]
- [[Geas]]
- [[Greater Restoration]]
- [[Insect Plague]]
- [[Mass Cure Wounds]]
- [[Planar Binding]]
- [[Reincarnate]]
- [[Scrying]]
- [[Tree Stride]]
- [[Wall of Stone]]

#### 6th Level

- [[Conjure Fey]]
- [[Find the Path]]
- [[Heal]]
- [[Heroes' Feast]]
- [[Move Earth]]
- [[Sunbeam]]
- [[Transport via Plants]]
- [[Volcanic Lightning]]
- [[Wall of Thorns]]
- [[Wind Walk]]

#### 7th Level

- [[Fire Storm]]
- [[Mirage Arcane]]
- [[Plane Shift]]
- [[Regenerate]]
- [[Reverse Gravity]]

#### 8th Level

- [[Animal Shapes]]
- [[Antipathy/Sympathy]]
- [[Control Weather]]
- [[Earthquake]]
- [[Empty Howl]]
- [[Feeblemind]]
- [[Sunburst]]

#### 9th Level

- [[Foresight]]
- [[Unweave]]
- [[Shapechange]]
- [[Storm of Vengeance]]
- [[True Resurrection]]