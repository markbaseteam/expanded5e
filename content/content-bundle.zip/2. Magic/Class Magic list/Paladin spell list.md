## Paladin Spells

#### 1st Level

- [[Bless]]
- [[Command]]
- [[Cure Wounds]]
- [[Detect Evil and Good]]
- [[Detect Magic]]
- [[Detect Poison and Disease]]
- [[Divine Favor]]
- [[Heroism]]
- [[Promise]]
- [[Protection from Evil and Good]]
- [[Purify Food and Drink]]
- [[Shield of Faith]]
- [[Shield of the Martyr]]

#### 2nd Level

- [[Aid]]
- [[Branding Smite]]
- [[Find Steed]]
- [[Lesser Restoration]]
- [[Locate Object]]
- [[Magic Weapon]]
- [[Protection from Poison]]
- [[Zone of Truth]]
- [[Crystalline Strike]]

#### 3rd Level

- [[Create Food and Water]]
- [[Daylight (Spell)]]
- [[Dispel Magic]]
- [[Magic Circle]]
- [[Remove Curse]]
- [[Revivify]]
- [[Aura of Wrath]]

#### 4th Level

- [[Banishment]]
- [[Conjure Phalanx]]
- [[Death Ward]]
- [[Locate Creature]]
- [[Divine Scourge]]

#### 5th Level

- [[Dispel Evil and Good]]
- [[Geas]]
- [[Raise Dead]]
- [[Aura of Resilience]]
