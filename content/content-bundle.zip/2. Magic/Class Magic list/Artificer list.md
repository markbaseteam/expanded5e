## Artificer Spells

#### Cantrips (0 Level)

- [[Amanuensis]]
- [[Dancing Lights]]
- [[Identify Poison and Disease]]
- [[Light (Spell)]]
- [[Mage Hand]]
- [[Mending]]
- [[Message]]
- [[Minor Illusion]]
- [[Prestidigitation]]
- [[Slow Poison]]
- [[True Strike]]
- [[Vicious Mockery]]
- [[Siren's Seeming]]

#### 1st Level

- [[Animal Friendship]]
- [[Bane]]
- [[Charm Person]]
- [[Comprehend Languages]]
- [[Cure Wounds]]
- [[Detect Magic]]
- [[Dispel Magics]]
- [[Disguise Self]]
- [[Faerie Fire]]
- [[Feather Fall]]
- [[Healing Word]]
- [[Heroism]]
- [[Hideous Laughter]]
- [[Identify]]
- [[Illusory Script]]
- [[Longstrider]]
- [[Silent Image]]
- [[Sleep]]
- [[Speak with Animals]]
- [[Thunderwave]]
- [[Unseen Servant]]
- [[Chorus of Scythes]]

#### 2nd Level

- [[Animal Messenger]]
- [[Blindness-Deafness]]
- [[Calm Emotions]]
- [[Detect Thoughts]]
- [[Enhance Ability]]
- [[Enthrall]]
- [[Heat Metal]]
- [[Hold Person]]
- [[Invisibility]]
- [[Knock]]
- [[Lesser Restoration]]
- [[Locate Animals or Plants]]
- [[Locate Object]]
- [[Magic Mouth]]
- [[Mimic Spell]]
- [[See Invisibility]]
- [[Shatter]]
- [[Silence]]
- [[Suggestion]]
- [[Zone of Truth]]
- [[Resounding Strike]]

#### 3rd Level

- [[Bestow Curse]]
- [[Clairvoyance]]
- [[Duplicate Potion]]
- [[Dispel Magic]]
- [[Fear]]
- [[Glyph of Warding]]
- [[Hypnotic Pattern]]
- [[Major Image]]
- [[Nondetection]]
- [[Plant Growth]]
- [[Sending]]
- [[Speak with Dead]]
- [[Speak with Plants]]
- [[Stinking Cloud]]
- [[Tiny Hut]]
- [[Tongues]]
- [[Broken Song]]

#### 4th Level

- [[Compulsion]]
- [[Confusion]]
- [[Dimension Door]]
- [[Freedom of Movement]]
- [[Greater Invisibility]]
- [[Hallucinatory Terrain]]
- [[Locate Creature]]
- [[Polymorph]]
- [[Degrading Chords]]

#### 5th Level

- [[Animate Objects]]
- [[Assets/Generated/Awaken]]
- [[Capture Spell]]
- [[Dominate Person]]
- [[Dream]]
- [[Geas]]
- [[Greater Restoration]]
- [[Hold Monster]]
- [[Legend Lore]]
- [[Mass Cure Wounds]]
- [[Mislead]]
- [[Modify Memory]]
- [[Planar Binding]]
- [[Raise Dead]]
- [[Scrying]]
- [[Seeming]]
- [[Teleportation Circle]]

#### 6th Level

- [[Eyebite]]
- [[Find the Path]]
- [[Guards and Wards]]
- [[Irresistible Dance]]
- [[Mass Suggestion]]
- [[Programmed Illusion]]
- [[True Seeing]]

#### 7th Level

- [[Arcane Sword]]
- [[Etherealness]]
- [[Forcecage]]
- [[Magnificent Mansion]]
- [[Mirage Arcane]]
- [[Project Image]]
- [[Regenerate]]
- [[Resurrection]]
- [[Symbol (Spell)]]
- [[Teleport]]

#### 8th Level

- [[Dominate Monster]]
- [[Feeblemind]]
- [[Glibness]]
- [[Mind Blank]]
- [[Power Word Stun]]

#### 9th Level

- [[Foresight]]
- [[Power Word Kill]]
- [[True Polymorph]]