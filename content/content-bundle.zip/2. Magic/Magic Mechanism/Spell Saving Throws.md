# Spell Saving Throws

Many spells specify that a target can make a saving throw to avoid some or all of a spell's effects. The spell specifies the ability that the target uses for the save and what happens on a success or failure.

The DC to resist one of your spells = 8 + your spellcasting ability modifier +  your proficiency bonus + any special modifiers.