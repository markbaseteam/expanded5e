## Overcharging Spells

**Overcharging Spells** You can attempt to cast a spell without requiring a spell slot by expending a number of Hit Dice equal to the level of the spell. When you do, make a Spell Check. The DC equals 10 + the level of the spell. If you match the DC it is still classes as as success but the player must roll the number of times equal to the level of the spell on the primary class wild magic table.

**Success:** You successfully cast the spell. 

**Failure:** The spell fails and you take Force damage equal to the Hit Dice expended. This damage cannot be reduced in any way. Whether the spellcasting is successful or fails, you immediately suffer 1 level of [[Exhaustion]].