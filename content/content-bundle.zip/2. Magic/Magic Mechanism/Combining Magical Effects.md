## Combining Magical Effects

The effects of different spells add together while the durations of those spells overlap. The effects of the same spell cast multiple times don't combine, however. Instead, the most potent effect-such as the highest bonus-from those castings applies while their durations overlap.

For example, if two clerics cast *[[Bless]]* on the same target, that character gains the spell's benefit only once; he or she doesn't get to roll two bonus dice.

However, if the characters cast complementary spells, the players can ask the DM for additional effects where it makes sense. 