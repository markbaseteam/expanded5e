## Identifying a spell as its cast

See variant rules 2 and 3 for other potential applications. You will also find a new *[[Dispel Magics]]* to **replace the original spell** of the same name. The remaining new spells can be added to your campaign's library of magic without further ado.

*Might vs. Magic* uses the following two rules instead:

1. While a creature is under an ongoing effect that reacts to a certain school of magic, it instantly recognizes a spell as belonging to that school as it sees or hears such a spell being cast.
2.  While a creature could prepare or cast a spell itself, it recognizes the spell by name and spell slot level when it sees or hears that spell being cast.

**When a spell is countered**, it fails to have any effect, but still expends an action, a spell slot, material components, or any special resources (such as Sorcery Points) as normal. A creature knows when its spell was countered, and it knows what creature countered its spell if it could see or hear that creature's reaction.

The time to try to counter a spell is **as it finishes** **casting** . So, if you wish to stop a spell with a ten minute casting time while it is five minutes into casting, don't bother countering, just attack the caster!