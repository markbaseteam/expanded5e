
## Prepare a Spell Charge

The **new spells in this supplement**  which instruct their caster to **"prepare a charge"** represent a new mechanism used for reactive magic. A creature may only hold one such charge at a time, regardless of which spell it is for. That charge is lost when the caster expends it as part of its reaction, when the caster is targeted by a sufficiently high level *[[Dispel Magic]]*, or when the spell finishes its duration.In *Might vs. Magic*, the main application of charged spells is to **replace and expand**  the basic Fifth Edition *[[Counterspell]]* with new spells such as *[[Break Spell]]*, *[[Absorb Spell]]*, and several others.
