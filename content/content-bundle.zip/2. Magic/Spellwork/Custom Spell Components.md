# Custom Spell Components

Casting spells with rare spell components enhance and modify spells in unique ways. There are SO many options here that you can give to your PC spellcasters to change the way they cast their spells. The best part is you can give them some CRAZY powerful things since they are tied to the material components that are CONSUMED upon casting the spell. You as the GM are in charge of how rare these things are and can give them as rewards when you see fit. Here are some ideas to get the sparks of inspiration going, but please take this and run with it:

- Change elemental type
- Increase the number of targets hit
- Change from single target to AoE
- Give [[Disadvantage]] on Save the creature makes
- Cast without verbal or somatic components
- Cast at a delayed point in time that you choose
- Cast from a remote location
- Combine effects from two spells into one

Add an additional condition or damage 2 Spells in 1 Turn. You can cast 2 spells in the same turn as long as at least 1 of the spells is at least 3 levels lower than the maximum spell level you can cast.

***Example:*** The highest level spell that a 9th-level caster can cast is 5th-level. This caster could cast 2 spells in 1 round as long as 1 of the spells is 2nd-level or lower (5 - 3 = 2). 

**Spell Criticals** When a creature rolls a natural 1 on a Save against a spell, you are able to reroll any damage dice from the spell. Instead of this more subtle effect for spells you could also apply the rules for [[Critical Strikes]] with Weapons (see page 160) to spells as well.

[[Overcharging Spells]]