# Spell Duels

When another creature that you can see begins casting a spell, you can use your Reaction to attempt to counter their spell with a spell of your own. The target spell and the spell that you cast must be within the same school of magic, be of 1st-level or higher, have a casting time of 1 Action, and overlap with each other if both spells cover an area of effect (such as a** **cone, cube, cylinder, line, or sphere).** 

***Example:*** Another creature casts *[[Cone of Cold]]*, you can use your [[Reaction]] to cast another Evocation spell, such as *[[Cone of Cold]]*, *[[Fireball]]*, *[[Lightning Bolt]]*, or *[[Ice Storm]]* to attempt to counter their spell, provided the area both spells cover are overlapping. Make a Spell Check contested by the target's Spell Check. You both add an amount equal to the spell level you are casting to your Check as well.

**Failure:** The target caster's spell succeeds and takes effect. 

**Success:** The target caster's spell fails and has no effect. 

**Tie:** The target caster's spell fails, has no effect, and both you and the target caster must roll on the Wild Magic Surge Table. If the target caster's spell fails, they can immediately cast a cantrip as part of the same Action they used to cast their spell. 

**Schools of Magic** 

The GM can say no to a spell working in a Spell Duel against another spell if they feel like it would not make sense conceptually. [[Dominate Person]] and [[Sleep]] are nowhere near the same kind of spell, but they are both in the Enchantment School. A GM could rule that you could not counter *[[Dominate Person]]* with *[[Sleep]]* for that reason, or you could rule that it DOES work and you flavor the description as *[[Sleep]]* countering them by putting them to sleep momentarily as they try and cast the spell. A possible modification could be that you can use a spell outside of the school of magic, if you provide creative reasoning as to how it would work and the GM approves of this.

## Spell Duels Chart

Compare the results of the Caster with the results of the Counterspeller

***Spell Misfire:*** When you cast a spell and get Spell Misfire something bad happens with the spell that is an unintended and negative result. This is completely up to the GM not only what happens here (if anything at all) but how severe of a problem it is when it happens. Here are examples of Spell Misfires to show you a glimpse into what is possible:

- *Dominate Person* is used to counterspell *Modify Memory,* which has a Spell Misfire as the result. Now the caster who casts *Modify Memory* could forget the last 24 hours of activities, gain a false memory of the NPC being a friend of theirs, or even forget the *Modify Memory* spell all together. 

- *Mass Suggestion* has a Spell Misfire when the counterspeller successfully counters by more than 5, with *Sleep*. Now not only does *Mass Suggestion* not go off on the intended targets, instead, *Mass Sleep* goes off on his allies and they all have to make a Constitution Save or fall asleep for 1 round. These are the types of on-the-fly rulings you can have fun with. 

- *Detect Thoughts* has a Spell Misfire when counterspelled by *Tongues*. For the next minute, the caster hears the thoughts of those around him, but in a language they don’t know. The cacophony causes them to have DisADV on Wisdom Checks and Saves. 

- *Polymorph* has a Spell Misfire when counterspelled by *Alter* *Self*. The caster’s feet become those of an animal, and the caster falls Prone. Standing up requires a **DC 15** Acrobatics Check, as the body is not used to having different appendages. •

- *Daylight* has a Spell Misfire when counterspelled by *Darkness*. The caster and nearby allies lose their shadows, which imposes DisADV on Charisma Saves and dampens their emotions.

**Difference Result** Caster wins by 5 or more. Spell goes off as normal and the Counterspeller gets a Spell Misfire Caster winsSpell goes off as normal Tie. Both spells fail and they both roll on the Wild Magic Surge Table Counterspeller wins. Spell is canceled Counterspeller wins by 5 or moreSpell is canceled and the Caster gets a Spell Misfire
