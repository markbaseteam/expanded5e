# Counterspell issues

***Side Note:*** For the entirety of my explanation, the two casters are named “the Caster” and “the Counterspeller”. *Counterspell* only costs a Reaction, which is very rarely used by casters in the first place and it shuts down the ACTION of the Caster, basically making them lose their turn. So now, you can cast a Cantrip when you get *Counterspell* cast against you. 

*Counterspell* being a contested Spell Check feels better to me since it gets across that mechanical feeling like two casters are testing their magic against each other… and they literally are with this method. It feels cheap for *Counterspell* to automatically counter any spell below 3rd-level, this feels off from the spirit of what *Counterspell* is. So I remove the bit about *Counterspell* always shutting down spells cast at a lower level than itself, and just always make the Counterspeller make a Check, or always make it a contested Check. The level of the Caster plays almost no part in how easily you can *Counterspell*. 

A level 5 Wizard could *Counterspell* a Lich just as easily as a level 20 Wizard, and vice versa. So now I changed that so you do add your Prof. Bonus to the Check you make to counter the spell. Now the power and capabilities of the caster factor into the contested Check. Counterspelling *Counterspell*… It’s just a mess. Just burns a bunch of spell slots and seems like the GM is a jerk if he has more Counterspellers on the enemy side. Also, if it’s a Reaction, it has to be faster than an Action, because you are reacting to something and shutting it down before it happens… but you would have to be extremely fast to even be able to see a *Counterspell* to attempt to *Counterspell* it if it’s that fast. If you want to allow a caster to counter a *Counterspell*… then I would still rule that the original caster who was casting a spell cannot cast *Counterspell* against the counterspeller. Doing so would STOP them from casting their own spell that they were in the middle of casting to *Counterspell* the *Counterspell*… even writing these sentences sounds dumb!

## (Rule) Counterspell

*3rd-level, Abjuration* ***Casting Time:*** 1 Reaction (which you take when you see a creature within 60ft of you casting a spell) ***Range:*** 60ft ***Components:*** S ***Duration:*** Instantaneous You attempt to interrupt a creature in the process of casting a spell. The target must be casting a spell with a casting time of 1 Action or longer. Make a Spell Check contested by the target's Spell Check. The target adds a bonus to its Check equal to the level of spell they are casting, you add a bonus to your check equal to the level at which you cast *Counterspell*. 

**Failure:** The target's spell succeeds and takes effect. 

**Success:** The target's spell fails and has no effect. 

**Tie:** The target's spell fails, has no effect, and both you and the target must roll on the Wild Magic Surge Table. If the target's spell fails, it can immediately cast a Cantrip as part of the same Action it used to cast its spell.

**Counterspell Options**

- Instead of a contested Spell Check, the Counterspeller rolls against the Caster’s Spell Save DC. Both the result and the DC are increased by a number equal to the level of spell being cast. 
- You get an additional +2 if you can identify the spell you are counterspelling. Usually this entails making an Arcana Check (**DC = 10 + Spell level**) to identify the spell. 
- Alternatively, the difference in spell level could affect BOTH the Counterspeller and the Caster. ***Example:*** The Counterspeller casts a 3rd-level *Counterspell* against a 6thlevel *Fireball*. The Counterspeller has a -3 to their Check, and the Caster gets a +3 to their Check. 
- If the Counterspeller and the Caster get the same number on the Check, The Caster loses their spell, and both the Counterspeller and the Caster must roll on the Wild Magic Surge Table.
-  I originally didn't let the Counterspeller upcast *Counterspell* due to the “meta” nature that this can be sometimes, especially if they know the spell level. But since there’s a chance that it doesn't work because I removed the “autocancel” effect, this is fine now. 
- Not allowing *Counterspell* to be cast on a *Counterspell*, or only allowing *Counterspell* to affect spells that take an Action to cast (as Bonus Actions and Reactions should be too fast). The logic is that a spell that can fire off in the time of a Reaction would have already finished by the time the opposing caster even saw that they were casting *Counterspell*. The only scenario I can see that this would make sense is if someone spent their turn holding an Action to *Counterspell* a caster, but only because they were focusing solely on that.