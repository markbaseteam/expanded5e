## Necromancy
Necromancy spells manipulate the energies of life and death. Such spells can grant an extra reserve of life force, drain the life energy from another creature, create the undead, or even bring the dead back to life.

Creating the undead through the use of necromancy spells such as [[Animate Dead]] is not a good act, and only evil casters use such spells frequently.