### Battle's Progeny

**Level** #cantrip [[Evocation]]

**School** #evocation

**Casting Time:** 1 bonus action

**Range:** #Self 

**Components:** V

**Duration:** Concentration, up to 1 minute

You spit a violent threat toward your enemies and call upon the martial prowess of your bloodline. For the duration of this spell, you can use your spellcasting ability instead of Strength for the attack and damage rolls of unarmed strikes, and the damage type and die for your unarmed strikes becomes 1d4 #force damage. Additionally, when you use the Attack action with an unarmed strike on your turn, you can make one additional unarmed strike as a bonus action.

***At Higher Levels*** This spell's damage increases by 2 when you reach 5th level (1d4+2), 11th level (1d4+4), and 17th level (1d4+6).