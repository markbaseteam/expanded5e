### Aura of Wrath

**Level** #3rd-level [[Evocation]]

**School** #evocation

**Casting Time:** 1 action

**Range:** Self (30 feet radius)

**Components:** V, S

**Duration:** Concentration, up to 1 minute

You call upon your power, righteous fury radiating from you in an aura with a 30-foot radius. Until the spell ends, the aura moves with you, centered on you. Each nonhostile creature in the aura (including you), may reroll weapon damage dice when they roll a 1 or a 2. If they reroll, they must use the new roll, even if the new roll is a 1 or a 2.