### Analyse Potion

**Level** #cantrip [[Transmutation]]

**School** #transmutation   

**Casting Time:** 1 action

**Range:** Touch

**Components:** V, S

**Duration:** Special

This spell instantly tells the caster the exact nature of a potion, including what it does, its duration, or any other pertinent information. It will not tell if the potion is cursed or if its true nature is magically concealed in some way.

Additionally, if the caster is proficent in alchemy, he is able to use the analysis to recreate the potion  if they can gather the materials and start crafting it within 1 hous. Crafting the potion in this way requires an alchemy check at DC 16 to succeed.

If the crafting does not begin within the hour, the fine details required to craft the potion are lost from memory, the crafting fails, and all the components are ruined.