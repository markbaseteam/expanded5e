### Bear Feet

**Level** #cantrip [[Transmutation]]

**School** #transmutation 

**Casting Time:** 1 action

**Range:** #Self 

**Components:** V, S

**Duration:** 1 hour

The caster transforms their feet into large bear paws that allow them to travel over rough terrain more effectively, increasing the woodland movement by 10 feet for the duration of the spell. Additionally, the bear feet five them an [[Advantage]] in climbing checks, and (if they are attemption to evade trackers) deception checks, since pursuers might mistake the paw prints for a real bear. Obviously, the latter would apply in regions that do not have a native bear population.