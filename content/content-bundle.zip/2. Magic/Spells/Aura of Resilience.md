### Aura of Resilience

**Level** #5th-level [[Evocation]]

**School** #evocation

**Casting Time:** 1 action

**Range:** #Self (30 feet radius)

**Components:** V, S

**Duration:** Concentration, up to 1 minute

Raw celestial energy emanates from you in an aura with a 30- foot radius, bolstering the spirits and bodies of those within it. Until the spell ends, the aura moves with you, centered on you. Each nonhostile creature in the aura (including you), gains 7d4 [[Temporary Hit Points]], [[Advantage]] on [[Death saving throws]], and resistance to #bludgeoning, #piercing, and #slashing damage. #Heal