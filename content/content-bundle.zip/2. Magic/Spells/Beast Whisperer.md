### Beast Whisperer

**Level** #cantrip [[Enchantment]]

**School** #enchantment 

**Casting Time:** 1 bonus action

**Range:** 30 feet

**Components:** V

**Duration:** Concentration, up to 6 hour

This spell creates a weak psychic link with a domesticated animal known to the caster, usually a mount, pack animal or pet. It gets the caster an advantage in animal handling checks specific to that beast for the duration of the spell. 

This connection can also allow the animal to warn the caster of danger, help the caster calm them if spooked, or impart simple ideas such as "stay put" or "follow me". This does not allow full communication of ideas or feelings, as with a familiar nor will it work on wild animals. 