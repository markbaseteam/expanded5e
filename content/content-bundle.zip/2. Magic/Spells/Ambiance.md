### Ambient Light

**Level** #cantrip  [[Transmutation]]

**School** #transmutation  

**Casting Time:** 1 action

**Range:** 10 feet

**Components:** V, S, M (a white feature and some silver thread)

**Duration:** 8 hours

The spell is often used by merchants to create a comfortable atmosphere for shop patrons by providing subtle background music and lightly perfuming the air. The specific music and perfume manifested is determined by the caster's personality, experience, the goods or services being offered, and the patrons who are likely to enter the establishment. The caster can allow the spell to devide on the specific music and scent, or they can select a combination they prefer instead. This spell will not produce any music or scents that the obviously offensive in any way.