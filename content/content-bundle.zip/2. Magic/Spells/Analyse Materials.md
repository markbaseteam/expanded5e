### Analyse Materials

**Level** #cantrip [[FearsD20 System/2. Magic/Spells/Divination]]

**School** #divination  

**Casting Time:** 1 action

**Range:** Torch

**Components:** V, M (a piece of charcoal)

**Duration:** Instanteous

This cantrip tells the caster what materials make up an object and thier general origins. For example, the spell could indicate that a particular sword was made from stell mined in the Barrier Mountains in the west, and that the hilt was made from ghost wood harvested from the forests of the north. The spell may also give an approximate age of the item's construction (GM's discretion). The spell will work on magic items, but it will only give information avout the materials used in their fabrication and not any magical properties.