### Amanuensis
**Level** [[Evocation]] #cantrip

**School** #evocation 

**Casting Time:** 1 action

**Range:**  10 feet

**Components:** S

**Duration:** Instantaneous

You swiftly brush your fingers across a blank page, filling it with identically copied text and images from another page you can see within range. Any similar, small surface area counts as a page for this purpose, such as one section of a large canvas. 

Magical text can be copied, but the copy retains no magic of its own.This spell can be repeated continuously to copy a longer volume of text, and unlike most spells, doing so does not interfere with a short rest. Ten minutes is long enough to copy 100 pages of content, and so on.
her, a target's hit points increase by an additional 5 for each slot level above 2nd.