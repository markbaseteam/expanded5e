### Analyse Value

**Level** #cantrip [[FearsD20 System/2. Magic/Spells/Divination]]

**School** #divination    

**Casting Time:** 1 action

**Range:** Touch

**Components:** V, M (a silver piece)

**Duration:** Instantaneous

This cantrip makes the caster aware of the current market value of any object. The value will be based on what people in the region are willing or able to pay and on the caster's personal experience. This spell does not guarantee that the object will sell, nor that the caster will get the fair market value if does sell.