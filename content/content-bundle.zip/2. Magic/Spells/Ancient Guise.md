### Ancient Guise

**Level** #4th-level [[Transmutation]]

**School** #transmutation 

**Casting Time:** 1 action

**Range:** #Self 

**Components:** V, S, M (a dried lizard tail)

**Duration:** Concentration, up to 10 minutes

Your skin turns to leathery scales as your teeth shapen to deadly points and hook-like claws tear their way from the tops of your feet. This transformation lasts until the spell ends and does not impact your ability to cast other spells. While you’re transformed you gain the following benefits:

 - Your base [[AC]] becomes 13 + your Wisdom modifier.

- You have proficiency when making unarmed strikes with your teeth or claws, which each count as natural melee weapons. Your teeth deal piercing damage equal to 1d10 + your Wisdom modifier and your claws deal slashing damage equal to 1d10 + your Wisdom modifier.

- You have [[Advantage]] on an [[Attack Rolls]] made against a creature if at least one of your allies is within 5 feet of the creature and that ally isn't [[Incapacitated]].

- If you move at least 20 feet straight toward a creature and then hit it with your claws on the same turn, that target must succeed on a Strength saving throw or be knocked [[Prone]]. If the target is prone, you can make an attack against it with your teeth as a [[bonus action]].