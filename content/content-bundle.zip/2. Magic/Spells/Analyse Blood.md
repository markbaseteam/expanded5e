### Analyse Blood

**Level** #cantrip  [[Necromancy]]

**School** #necromancy 

**Casting Time:** 1 action

**Range:** 5 feet

**Components:** V, M (a sample of blood)

**Duration:** 1 hour

This cantrip can tell the caster something about a specific creation from some of its blood. When cast on a sample of fresh blood (less than 24 hours old), the caster gains knowledge about the nature and location of the donar. It can tell something about the creature's lifestyle, habits, ite current state, and a general idae of its current direction and distance. This spell will not work if the creature is on another plane.