### Absorb Spell
**Level** #3rd-level [[Abjuration]]

**School** #abjuration 

**Casting Time:** 1 action

**Range:**  Self (60-foot reaction)

**Components:** S

**Duration:** Charged, up to 1 hour


You name a school of magic and prepare a charge to counter it. You may expend your charge as a reaction to absorb one spell of that school as you see or hear it being cast by a creature within 60 feet of you. When you do so, the spell is countered. At the start of your next turn, you may regain one expended spell slot no higher than the absorbed spell’s level (none for cantrips). Doing so requires an action if the spell slot is 6th level or higher, or a bonus action if the spell slot is 5th level or lower.

***At Higher Levels.*** If you cast this spell using a spell slot of 4th level or higher, you may name one additional school of magic for each slot level above 3rd.If Divination is among the schools named, extend the range of your reaction to 90 feet.If Illusion is among the schools named, this spell cannot be dispelled or countered.
