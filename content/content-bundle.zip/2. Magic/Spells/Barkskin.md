### Barkskin

**Level** #2nd-level [[Transmutation]]

**School** #transmutation 

**Casting Time:** 1 action

**Range:** #Touch

**Components:** V, S, M (a handful of oak bark)

**Duration:** Concentration, up to 1 hour

You touch a willing creature. Until the spell ends, the target's skin has a rough, bark-like appearance, and the target's [[AC]] can't be less than 16, regardless of what kind of armor it is wearing.