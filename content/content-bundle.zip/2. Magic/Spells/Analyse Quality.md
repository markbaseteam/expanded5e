### Analyse Quality

**Level** #cantrip [[FearsD20 System/2. Magic/Spells/Divination]]

**School** #divination    

**Casting Time:** 1 action

**Range:** Touch

**Components:** V, M (a bit of quartz)

**Duration:** Instantaneous

This cantrip informs the caster of the overall quality of an item and highlights any defects. It will indicate if it is masterwork, and if it is likely to impact any benefits based on its quality. It will work on magic items, but will not provide any information regarding its magical properties.