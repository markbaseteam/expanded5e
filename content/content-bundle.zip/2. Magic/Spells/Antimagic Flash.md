### Antimagic Flash
*2nd-level abjuration*

**Casting Time:** 1 action

**Range:**  Self (20-foot radius)

**Components:** V, S

**Duration:** Concentration, up to 1 round

You name a school of magic and prepare to counter it. Until the start of your next turn, you counter all spells of that school cast by creatures within 20 feet of you, and you cannot take reactions.

***At Higher Levels.*** If you cast this spell using a spell slot of 3rd level or higher, you may name one additional school of magic for each slot level above 2nd.If Divination is among the schools named, extend the radius of your counterspells to 40 feet.If Illusion is among the schools named, this spell cannot be dispelled or countered.