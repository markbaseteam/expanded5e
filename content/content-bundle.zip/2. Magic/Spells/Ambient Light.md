### Ambient Light

**Level** #cantrip  [[Transmutation]]

**School** #transmutation  

**Casting Time:** 1 action

**Range:** 10 feet

**Components:** V, S, M (a pinch of copper dust)

**Duration:** 30 minutes

This spell increases the ambient light within a 30-feet area. It removes all deep shadows and makes it easy to examine objects.Anyone trying to hide within the spell boundaries will do so at a [[Disadvantage]].