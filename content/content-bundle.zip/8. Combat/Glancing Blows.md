## Glancing Blows

If a creature makes an Attack against you and EXACTLY hits your AC, then the Attack hits (as usual) but it’s a Glancing Blow and it deals half damage instead. If you are using any effects or attack modifier seperate from your attack (slayers prey, melee spells etc, smite) these must be rolled as seperate attacks but will if they match the AC they will deal full damage.

If the creature is two sizes bigger than you. Make a Athletics or Acrobatics check or be pushed 5ft away from the creature. Nat 1, you armor takes damage and is reduced by 1.

***Example:*** Your AC is 18. If a creature’s Attack totals below 18, they miss and deal no damage. If a creature’s Attack totals above 18, they hit and deal full damage. However, if a creature’s Attack totals EXACTLY 18, they hit but only deal half damage. Keep in mind that this rule will decrease the amount of damage creatures take. Normally, exactly hitting a target’s AC would deal full damage, so this does make creatures last longer in combat. 