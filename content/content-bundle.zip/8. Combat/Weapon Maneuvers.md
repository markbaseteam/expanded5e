## Weapon Maneuvers
A maneuvers can be used by any character as long as they are wielding the appropriate weapon and are proficient with it. 

If a weapon maneuver requires a creature to make a [[(Saving Throw) Weapons Maneuver]] , the DC equals 8 + the attacker’s proficiency bonus + the attacker’s Strength or Dexterity modifier (attacker’s choice). Unless specified, these maneuvers have only their listed effect and don’t deal normal weapon damage. Unless with associated feat.

## Critical Hit
Roll normal damage if maneuver deals no damage, double if it does. No additional effects