# Interaction Action

On a PC’s turn, they can use their Interaction to perform 1 Check to gain extra information or interact with the world around them. 

Players only have an Action, and then sometimes they have abilities that let them perform a Bonus Action… and apart from their movement, that's IT! Sometimes players are afraid to make big moves or do other cool things because they don't want to “waste their action” on something small. 

Introducing the concept of an Interaction encourages players to think about what’s possible and INTERACT with the environment during combat.

Let them ask questions with their Interaction and maybe give them clues about the enemies’ weaknesses or the layout of the battlefield. Even something like the intentions of who an enemy is going to attack next is possible. They could also ask to do something VERY small that you don't want to make them use their [[Action]] (or [[Bonus Action]]) for. 

Let them try to flip over a table with their Interaction, and they make a Check and then can proceed with their turn after whatever happens If they fail that Check they don't feel like they wasted anything because it's just a simple Interaction. 

You also don't have to make this be a Check of any kind. You can just tell them information based on what they ask, or just have something happen if it’s that minor. This is also great for both new and veteran players. New players can basically ask for help in what to do next and not be afraid to ask questions about what’s going on. Veteran players can try and learn more information about what’s going on and maybe learn about interesting mechanics.

***DC Tip:*** I’ve had players ask REALLY interesting questions about the terrain or monsters… and after their question… I was so surprised by how cool of an idea it was that I added it to the combat and it became a cool new mechanic. Let your players think about your world and then run with those thoughts.