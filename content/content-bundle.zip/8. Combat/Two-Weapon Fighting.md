### Two-Weapon Fighting

When you take the Attack action and attack with a [[light melee weapon]] that you're holding in one hand, you can use a [[bonus action]] to attack with a different [[light melee weapon]] that you're holding in the other hand. You don't add your ability modifier to the damage of the [[bonus attack]], unless that modifier is negative.

If either weapon has the [[Thrown]] property, you can throw the weapon, instead of making a melee attack with it.