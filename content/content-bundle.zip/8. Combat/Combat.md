# Combat

A typical combat encounter is a clash between two sides, a flurry of weapon swings, feints, parries, footwork, and spellcasting. The game organizes the chaos of combat into a cycle of rounds and turns. A **round** represents about 6 seconds in the game world. During a round, each participant in a battle takes a **turn**. The order of turns is determined at the beginning of a combat encounter, when everyone rolls [[Initiative]] or [[(Rule) Variant initiative checks]] . Once everyone has taken a turn, the fight continues to the next round if neither side has defeated the other.

## Combat Step by Step

1. **Determine surprise.** The GM determines whether anyone involved in the combat encounter is impacted by [[Surprise]].
2. **Establish positions.** The GM decides where all the characters and monsters are located. Given the adventurers' marching order or their stated positions in the room or other location, the GM figures out where the adversaries are̶how far away and in what direction.
3. **Roll [[Initiative]].** Everyone involved in the combat encounter rolls [[Initiative]], determining the order of combatants' turns.
4. **Take turns.** Each participant in the battle takes a turn in [[Initiative]] order.
	1. Each turn has the following;
		1. [[Interaction Action]]
		2. [[Action]]
		3. [[Bonus Action]]
5. **Begin the next round.** When everyone involved in the combat has had a turn, the round ends. Repeat step 4 until the fighting stops.


## [[Initiative]]

[[Initiative]] determines the order of turns during combat. When combat starts, every participant makes a Dexterity check to determine their place in the [[Initiative]] order. The GM makes one roll for an entire group of identical creatures, so each member of the group acts at the same time.

The GM ranks the combatants in order from the one with the highest Dexterity check total to the one with the lowest. This is the order (called the [[Initiative]] order) in which they act during each round. The [[Initiative]] order remains the same from round to round.

If a tie occurs, the GM decides the order among tied GM-controlled creatures, and the players decide the order among their tied characters. The GM can decide the order if the tie is between a monster and a player character. Optionally, the GM can have the tied characters and monsters each roll a d20 to determine the order, highest roll going first.

## Your Turn

On your turn, you can **move** a distance up to your speed and take **one** [[action]] and **one** [[Interaction Action]]. You decide whether to move first or take your action first. Your speed- sometimes called your walking speed-is noted on your character sheet.

The most common actions you can take are described in the "Actions in Combat" section later in this chapter. Many class features and other abilities provide additional options for your action.

The "Movement and Position" section later in this chapter gives the rules for your move.

You can forgo moving, taking an action, or doing anything at all on your turn. If you can't decide what to do on your turn, consider taking the [[Dodge]], [[Protected]], or [[Ready]] action, as described in "Actions in Combat."

## Bonus Actions

Various class features, spells, and other abilities let you take an additional action on your turn called a bonus action. The Cunning Action feature, for example, allows a rogue to take a bonus action. You can take a bonus action only when a special ability, spell, or other feature of the game states that you can do something as a bonus action. You otherwise don't have a bonus action to take.

You can take only one bonus action on your turn, so you must choose which bonus action to use when you have more than one available.

You choose when to take a bonus action during your turn, unless the bonus action's timing is specified, and anything that deprives you of your ability to take actions also prevents you from taking a bonus action.

## Other Activity on Your Turn

Your turn can include a variety of flourishes that require neither your action nor your move.

You can communicate however you are able, through brief utterances and gestures, as you take your turn.

You can also interact with one object or feature of the environment for free, during either your move or your action. For example, you could open a door during your move as you stride toward a foe, or you could draw your weapon as part of the same action you use to attack.

If you want to interact with a second object, you need to use your action. Some magic items and other special objects always require an action to use, as stated in their descriptions.

The GM might require you to use an action for any of these activities when it needs special care or when it presents an unusual obstacle. For instance, the GM could reasonably expect you to use an action to open a stuck door or turn a crank to lower a drawbridge.

# Reactions

Certain special abilities, spells, and situations allow you to take a special action called a reaction. A reaction is an instant response to a trigger of some kind, which can occur on your turn or on someone else's. The opportunity attack, described later in this chapter, is the most common type of reaction.

When you take a reaction, you can't take another one until the start of your next turn. If the reaction interrupts another creature's turn, that creature can continue its turn right after the reaction.

# Movement and Position

In combat, characters and monsters are in constant motion, often using movement and position to gain the upper hand.

On your turn, you can move a distance up to your speed. You can use as much or as little of your speed as you like on your turn, following the rules here.

Your movement can include jumping, climbing, and swimming. These different modes of movement can be combined with walking, or they can constitute your entire move. However you're moving, you deduct the distance of each part of your move from your speed until it is used up or until you are done moving.

## Breaking Up Your Move

You can break up your movement on your turn, using some of your speed before and after your action. For example, if you have a speed of 30 feet, you can move 10 feet, take your action, and then move 20 feet.

### Moving between Attacks

If you take an action that includes more than one weapon attack, you can break up your movement even further by moving between those attacks. For example, a fighter who can make two attacks with the Extra Attack feature and who has a speed of 25 feet could move 10 feet, make an attack, move 15 feet, and then attack again.

### Using Different Speeds

If you have more than one speed, such as your walking speed and a flying speed, you can switch back and forth between your speeds during your move. Whenever you switch, subtract the distance you've already moved from the new speed. The result determines how much farther you can move. If the result is 0 or less, you can't use the new speed during the current move.

For example, if you have a speed of 30 and a flying speed of 60 because a wizard cast the *[[Fly]]* spell on you, you could fly 20 feet, then walk 10 feet, and then leap into the air to fly 30 feet more.

## [[Difficult Terrain]]

Combat rarely takes place in bare rooms or on featureless plains. Boulder-strewn caverns, briar-choked forests, treacherous staircases-the setting of a typical fight contains difficult terrain.

Every foot of movement in difficult terrain costs 1 extra foot. This rule is true even if multiple things in a space count as difficult terrain.

Low furniture, rubble, undergrowth, steep stairs, snow, and shallow bogs are examples of difficult terrain. The space of another creature, whether hostile or not, also counts as difficult terrain.

## Being [[Prone]]

Combatants often find themselves lying on the ground, either because they are knocked down or because they throw themselves down. In the game, they are [[Prone]], a condition described in appendix A.

You can **drop [[Prone]]** without using any of your speed. **Standing up** takes more effort; doing so costs an amount of movement equal to half your speed. For example, if your speed is 30 feet, you must spend

15 feet of movement to stand up. You can't stand up if you don't have enough movement left or if your speed is 0.

To move while [[Prone]], you must **crawl** or use magic such as teleportation. Every foot of movement while crawling costs 1 extra foot. Crawling 1 foot in difficult terrain, therefore, costs 3 feet of movement.

> **Interacting with Objects Around You**
>
>Here are a few examples of the sorts of thing you can do in tandem with your movement and action:
>
>- draw or sheathe a sword
>- open or close a door
>- withdraw a potion from your backpack
>- pick up a dropped axe
>- take a bauble from a table
>- remove a ring from your finger
>- stuff some food into your mouth
>- plant a banner in the ground
>- fish a few coins from your belt pouch
>- drink all the ale in a flagon
>- throw a lever or a switch
>- pull a torch from a sconce
>- take a book from a shelf you can reach
>- extinguish a small flame
>- don a mask
>- pull the hood of your cloak up and over your head
>- put your ear to a door
>- kick a small stone
>- turn a key in a lock
>- tap the floor with a 10-foot pole
>- hand an item to another character

## Moving Around Other Creatures

You can move through a nonhostile creature's space. In contrast, you can move through a hostile creature's space only if the creature is at least two sizes larger or smaller than you. Remember that another creature's space is difficult terrain for you.

Whether a creature is a friend or an enemy, you can't willingly end your move in its space.

If you leave a hostile creature's reach during your move, you provoke an opportunity attack, as explained later in the chapter.

## Flying Movement

Flying creatures enjoy many benefits of mobility, but they must also deal with the danger of falling. If a flying creature is knocked [[Prone]], has its speed reduced to 0, or is otherwise deprived of the ability to move, the creature falls, unless it has the ability to hover or it is being held aloft by magic, such as by the *fly* spell.

## Creature Size

Each creature takes up a different amount of space. The Size Categories table shows how much space a creature of a particular size controls in combat. Objects sometimes use the same size categories.

**Table- Creature Size**

| Size       | Space                  |
|------------|------------------------|
| Tiny       | 2 1/2 by 2 1/2 ft.     |
| Small      | 5 by 5 ft.             |
| Medium     | 5 by 5 ft.             |
| Large      | 10 by 10 ft.           |
| Huge       | 15 by 15 ft.           |
| Gargantuan | 20 by 20 ft. or larger |
|            |                        |

### Space

A creature's space is the area in feet that it effectively controls in combat, not an expression of its physical dimensions. A typical Medium creature isn't 5 feet wide, for example, but it does control a space that wide. If a Medium hobgoblin stands in a 5-foot wide doorway, other creatures can't get through unless the hobgoblin lets them.

A creature's space also reflects the area it needs to fight effectively. For that reason, there's a limit to the number of creatures that can surround another creature in combat. Assuming Medium combatants, eight creatures can fit in a 5-foot radius around another one.

Because larger creatures take up more space, fewer of them can surround a creature. If four Large creatures crowd around a Medium or smaller one, there's little room for anyone else. In contrast, as many as twenty Medium creatures can surround a Gargantuan one.

#### Squeezing into a Smaller Space

A creature can squeeze through a space that is large enough for a creature one size smaller than it. Thus, a Large creature can squeeze through a passage that's only 5 feet wide. While squeezing through a space, a creature must spend 1 extra foot for every foot it moves there, and it has disadvantage on [[Attack Rolls]] and Dexterity saving throws. [[Attack Rolls]] against the creature have advantage while it's in the smaller space.

# Actions in Combat

When you take your action on your turn, you can take one of the actions presented here, an action you gained from your class or a special feature, or an action that you improvise. Many monsters have action options of their own in their stat blocks.

When you describe an action not detailed elsewhere in the rules, the GM tells you whether that action is possible and what kind of roll you need to make, if any, to determine success or failure.

1. [[Attack]]
2. [[Cast a Spell]]
3. [[Dash]]

## Disengage

If you take the [[Disengage]] action, your movement doesn't provoke [[Opportunity attacks]] for the rest of the turn.

## [[Dodge]]

When you take the [[Dodge]] action, you focus entirely on avoiding attacks. Until the start of your next turn, any attack roll made against you has disadvantage if you can see the attacker, and you make Dexterity saving throws with advantage. You lose this benefit if you are [[Incapacitated]] (as explained in appendix A) or if your speed drops to 0.

## Help

## [[Hide]]

When you take the [[Hide]] action, you make a Dexterity (Stealth) check in an attempt to [[Hide]], following the rules for hiding. If you succeed, you gain certain benefits, as described in the "Unseen Attackers and Targets" section later in this chapter.

[[Ready]]

# Making an Attack

Whether you're striking with a melee weapon, firing a weapon at range, or making an attack roll as part of a spell, an attack has a simple structure.

- **Choose a target**. Pick a target within your attack's **Range:** a creature, an object, or a location.
- **Determine modifiers**. The GM determines whether the target has cover and whether you have advantage or disadvantage against the target. In addition, spells, special abilities, and other effects can apply penalties or bonuses to your attack roll.
- **Resolve the attack**. You make the attack roll. On a hit, you roll damage, unless the particular attack has rules that specify otherwise. Some attacks cause special effects in addition to or instead of damage.

If there's ever any question whether something you're doing counts as an attack, the rule is simple: if you're making an attack roll, you're making an attack.

## Attack Rolls

When you make an attack, your attack roll determines whether the attack hits or misses. To make an attack roll, roll a d20 and add the appropriate modifiers. If the total of the roll plus modifiers equals or exceeds the target's Armor Class (AC), the attack hits. The AC of a character is determined at character creation, whereas the AC of a monster is in its stat block.

### Modifiers to the Roll

When a character makes an attack roll, the two most common modifiers to the roll are an ability modifier and the character's proficiency bonus. When a monster makes an attack roll, it uses whatever modifier is provided in its stat block.

***Ability Modifier.*** The ability modifier used for a melee weapon attack is Strength, and the ability modifier used for a ranged weapon attack is Dexterity. Weapons that have the [[Finesse]] or thrown property break this rule.

Some spells also require an attack roll. The ability modifier used for a spell attack depends on the spellcasting ability of the spellcaster.

***Proficiency Bonus.*** You add your proficiency bonus to your attack roll when you attack using a weapon with which you have proficiency, as well as when you attack with a spell.

### Rolling 1 or 20

Sometimes fate blesses or curses a combatant, causing the novice to hit and the veteran to miss.

If the d20 roll for an attack is a 20, the attack hits regardless of any modifiers or the target's AC. This is called a [[Critical Hit]], which is explained later in this chapter.

If the d20 roll for an attack is a 1, the attack misses regardless of any modifiers or the target's AC.

## Unseen Attackers and Targets

Combatants often try to escape their foes' notice by hiding, casting the invisibility spell, or lurking in darkness.

When you attack a target that you can't see, you have disadvantage on the attack roll. This is true whether you're guessing the target's location or you're targeting a creature you can hear but not see. If the target isn't in the location you targeted, you automatically miss, but the GM typically just says that the attack missed, not whether you guessed the target's location correctly.

When a creature can't see you, you have advantage on [[Attack Rolls]] against it. If you are hidden-both unseen and unheard-when you make an attack, you give away your location when the attack hits or misses.

## Ranged Attacks

When you make a ranged attack, you fire a bow or a crossbow, hurl a [[FearsD20 System/8. Combat/Weapons/Thrown Weapons/Handaxe]], or otherwise send projectiles to strike a foe at a distance. A monster might shoot spines from its tail. Many spells also involve making a ranged attack.

### Range

You can make ranged attacks only against targets within a specified range.

If a ranged attack, such as one made with a spell, has a single range, you can't attack a target beyond this range.

Some ranged attacks, such as those made with a [[FearsD20 System/3. Items/Equipment/Weapons/Martial Ranged Weapons/Longbow]] or a shortbow, have two ranges. The smaller number is the normal range, and the larger number is the long range. Your attack roll has disadvantage when your target is beyond normal range, and you can't attack a target beyond the long range.

### Ranged Attacks in Close Combat

Aiming a ranged attack is more difficult when a foe is next to you. When you make a ranged attack with a weapon, a spell, or some other means, you have disadvantage on the attack roll if you are within 5 feet of a hostile creature who can see you and who isn't [[Incapacitated]].

## Melee Attacks

Used in hand-to-hand combat, a melee attack allows you to attack a foe within your reach. A melee attack typically uses a handheld weapon such as a sword, a warhammer, or an axe. A typical monster makes a melee attack when it strikes with its claws, horns, teeth, tentacles, or other body part. A few spells also involve making a melee attack.

Most creatures have a 5-foot **reach** and can thus attack targets within 5 feet of them when making a melee attack. Certain creatures (typically those larger than Medium) have melee attacks with a greater reach than 5 feet, as noted in their descriptions.

Instead of using a weapon to make a melee weapon attack, you can use an **unarmed strike**: a punch, kick, head-butt, or similar forceful blow (none of which count as weapons). On a hit, an unarmed strike deals bludgeoning damage equal to 1 + your Strength modifier. You are proficient with your unarmed strikes.

>***Contests in Combat***
>
>Battle often involves pitting your prowess against that of your foe. Such a challenge is represented by a contest. This section includes the most common contests that require an action in combat: [[Grapple]] and shoving a creature. The GM can use these contests as models for improvising others.

#### Opportunity Attacks

In a fight, everyone is constantly watching for a chance to strike an enemy who is fleeing or passing by. Such a strike is called an opportunity attack.

You can make an opportunity attack when a hostile creature that you can see moves out of your reach. To make the opportunity attack, you use your reaction to make one melee attack against the provoking creature. The attack occurs right before the creature leaves your reach.

You can avoid provoking an opportunity attack by taking the [[Disengage]] action. You also don't provoke an opportunity attack when you teleport or when someone or something moves you without using your movement, action, or reaction. For example, you don't provoke an opportunity attack if an explosion hurls you out of a foe's reach or if gravity causes you to fall past an enemy.

### Two-Weapon Fighting

When you take the Attack action and attack with a light melee weapon that you're holding in one hand, you can use a bonus action to attack with a different light melee weapon that you're holding in the other hand. You don't add your ability modifier to the damage of the bonus attack, unless that modifier is negative.

If either weapon has the thrown property, you can throw the weapon, instead of making a melee attack with it.

### Grappling

When you want to grab a creature or wrestle with it, you can use the Attack action to make a special melee attack, a grapple. If you're able to make multiple attacks with the Attack action, this attack replaces one of them.

The target of your grapple must be no more than one size larger than you and must be within your reach. Using at least one free hand, you try to seize the target by making a grapple check instead of an attack roll: a Strength (Athletics) check contested by the target's Strength (Athletics) or Dexterity (Acrobatics) check (the target chooses the ability to use). You succeed automatically if the target is [[Incapacitated]]. If you succeed, you subject the target to the [[Grappled]] condition (see appendix ##). The condition specifies the things that end it, and you can release the target whenever you like (no action required).

***Escaping a Grapple***. A [[Grappled]] creature can use its action to escape. To do so, it must succeed on a Strength (Athletics) or Dexterity (Acrobatics) check contested by your Strength (Athletics) check.

***Moving a [[Grappled]] Creature***. When you move, you can drag or carry the [[Grappled]] creature with you, but your speed is halved, unless the creature is two or more sizes smaller than you.

### Shoving a Creature

Using the Attack action, you can make a special melee attack to shove a creature, either to knock it [[Prone]] or push it away from you. If you're able to make multiple attacks with the Attack action, this attack replaces one of them.

The target must be no more than one size larger than you and must be within your reach. Instead of making an attack roll, you make a Strength (Athletics) check contested by the target's Strength (Athletics) or Dexterity (Acrobatics) check (the target chooses the ability to use). You succeed automatically if the target is [[Incapacitated]]. If you succeed, you either knock the target [[Prone]] or push it 5 feet away from you.

[[Cover]]

## Damage and Healing

Injury and the risk of death are constant companions of those who explore fantasy gaming worlds. The thrust of a sword, a well-placed arrow, or a blast of flame from a *[[Fireball]]* spell all have the potential to damage, or even kill, the hardiest of creatures.

### Hit Points

Hit points represent a combination of physical and mental durability, the will to live, and luck. Creatures with more hit points are more difficult to kill. Those with fewer hit points are more fragile.

A creature's current hit points (usually just called hit points) can be any number from the creature's hit point maximum down to 0. This number changes frequently as a creature takes damage or receives healing.

Whenever a creature takes damage, that damage is subtracted from its hit points. The loss of hit points has no effect on a creature's capabilities until the creature drops to 0 hit points.

### Damage Rolls

Each weapon, spell, and harmful monster ability specifies the damage it deals. You roll the damage die or dice, add any modifiers, and apply the damage to your target. Magic weapons, special abilities, and other factors can grant a bonus to damage. With a penalty, it is possible to deal 0 damage, but never negative damage.

When attacking with a **weapon**, you add your ability modifier-the same modifier used for the attack roll-to the damage. A **spell** tells you which dice to roll for damage and whether to add any modifiers.

If a spell or other effect deals damage to **more than one target** at the same time, roll the damage once for all of them. For example, when a wizard casts *[[Fireball]]* or a cleric casts *[[Flame Strike]]*, the spell's damage is rolled once for all creatures caught in the blast.

### Critical Hits

When you score a [[Critical Hit]], you get to roll extra dice for the attack's damage against the target. Roll all of the attack's damage dice twice and add them together. Then add any relevant modifiers as normal. To speed up play, you can roll all the damage dice at once.

For example, if you score a [[Critical Hit]] with a dagger, roll 2d4 for the damage, rather than 1d4, and then add your relevant ability modifier. If the attack involves other damage dice, such as from the rogue's Sneak Attack feature, you roll those dice twice as well.

### Damage Types

Different attacks, damaging spells, and other harmful effects deal different types of damage. Damage types have no rules of their own, but other rules, such as damage resistance, rely on the types.

The damage types follow, with examples to help a GM assign a damage type to a new effect.

***Acid***. The corrosive spray of a black dragon's breath and the dissolving enzymes secreted by a black pudding deal acid damage.

***Bludgeoning***. Blunt force attacks-hammers, falling, constriction, and the like-deal bludgeoning damage.

***Cold***. The infernal chill radiating from an ice devil's spear and the frigid blast of a white dragon's breath deal cold damage.

***Fire***. Red dragons breathe fire, and many spells conjure flames to deal fire damage.

***Force***. Force is pure magical energy focused into a damaging form. Most effects that deal force damage are spells, including *[[Magic Missile]]* and *[[Spiritual Weapon]]*.

***Lightning***. A *[[Lightning Bolt]]* spell and a blue dragon's breath deal lightning damage.

***Necrotic***. Necrotic damage, dealt by certain undead and a spell such as *[[Chill Touch]]*, withers matter and even the soul.

***Piercing***. Puncturing and impaling attacks, including spears and monsters' bites, deal piercing damage.

***Poison***. Venomous stings and the toxic gas of a green dragon's breath deal poison damage.

***Psychic***. Mental abilities such as a mind flayer's psionic blast deal psychic damage.

***Radiant***. Radiant damage, dealt by a cleric's *[[Flame Strike]]* spell or an angel's smiting weapon, sears the flesh like fire and overloads the spirit with power.

***Slashing***. Swords, axes, and monsters' claws deal slashing damage.

***Thunder***. A concussive burst of sound, such as the effect of the *[[Thunderwave]]* spell, deals thunder damage.

### Damage Resistance and Vulnerability

Some creatures and objects are exceedingly difficult or unusually easy to hurt with certain types of damage.

If a creature or an object has **resistance** to a damage type, damage of that type is halved against it. If a creature or an object has **vulnerability** to a damage type, damage of that type is doubled against it.

Resistance and then vulnerability are applied after all other modifiers to damage. For example, a creature has resistance to bludgeoning damage and is hit by an attack that deals 25 bludgeoning damage. The creature is also within a magical aura that reduces all damage by 5. The 25 damage is first reduced by 5 and then halved, so the creature takes 10 damage.

Multiple instances of resistance or vulnerability that affect the same damage type count as only one instance. For example, if a creature has resistance to fire damage as well as resistance to all nonmagical damage, the damage of a nonmagical fire is reduced by half against the creature, not reduced by three-quarters.

### Healing

Unless it results in death, damage isn't permanent. Even death is reversible through powerful magic. Rest can restore a creature's hit points, and magical methods such as a *[[Cure Wounds]]* spell or a *[[Potion of Healing]]* can remove damage in an instant.

When a creature receives healing of any kind, hit points regained are added to its current hit points. A creature's hit points can't exceed its hit point maximum, so any hit points regained in excess of this number are lost. For example, a druid grants a ranger 8 hit points of healing. If the ranger has 14 current hit points and has a hit point maximum of 20, the ranger regains 6 hit points from the druid, not 8.

A creature that has died can't regain hit points until magic such as the *[[Revivify]]* spell has restored it to life.

### Dropping to 0 Hit Points

When you drop to 0 hit points, you either die outright or fall [[Unconscious]], as explained in the following sections.

### Instant Death

Massive damage can kill you instantly. When damage reduces you to 0 hit points and there is damage remaining, you die if the remaining damage equals or exceeds your hit point maximum.

For example, a cleric with a maximum of 12 hit points currently has 6 hit points. If she takes 18 damage from an attack, she is reduced to 0 hit points, but 12 damage remains. Because the remaining damage equals her hit point maximum, the cleric dies.

### Falling [[Unconscious]]

If damage reduces you to 0 hit points and fails to kill you, you fall [[Unconscious]] (see appendix ##). This unconsciousness ends if you regain any hit points.

[[Death saving throws]]

### Monsters and Death

Most GMs have a monster die the instant it drops to 0 hit points, rather than having it fall [[Unconscious]] and make [[Death saving throws]].

Mighty villains and special nonplayer characters are common exceptions; the GM might have them fall [[Unconscious]] and follow the same rules as player characters.

## Knocking a Creature Out

Sometimes an attacker wants to incapacitate a foe, rather than deal a killing blow. When an attacker reduces a creature to 0 hit points with a melee attack, the attacker can knock the creature out. The attacker can make this choice the instant the damage is dealt. The creature falls [[Unconscious]] and is stable.

[[Temporary Hit Points]]
