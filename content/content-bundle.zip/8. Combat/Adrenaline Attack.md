### Adrenaline Attack

When you make a Weapon Attack, you can choose to turn it into an Adrenaline Attack. When you do so, you gain the following benefits:

- You gain [[Advantage]] on the Attack.
- You add 1 additional weapon damage die to the Attack.
- You can choose to reroll the Attack's damage dice. You must use the new total.
- On a hit, the Attack becomes a [[Critical Hit]].

Immediately after making the Attack, you suffer 1 level of [[Exhaustion]]. You can use this ability once per [[Short rest]].