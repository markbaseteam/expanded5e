## Monsters
Any creature that has more than 1 character surrounding them can not make [[Opportunity attacks]] without triggering [[Opportunity attacks]] against it. Attacks gain [[Advantage]] against it. 

If the creature has the ability to defend it gains the [[Protected]] condition if they are within 10ft of another monster, this uses all half of movement of the monster within 10ft of the monster.

## Players
Any creature that has more than 1 character surrounding them can not make [[Opportunity attacks]] without triggering [[Opportunity attacks]] against it. Attacks gain [[Advantage]] against it. 

A player that has more than 1 monster around rolls either rolls a;

- Acrobatic Saving Throw
- Athletics Saving Throw
- Survival Saving Throw

Or each attack in which the player reacts to triggers an opportunity attack with [[Disadvantage]] from those surrounding them.

If the creature has the ability to defend it gains the [[Fortified]] condition if they are within 5ft of the player at the cost the other players [[reaction]].