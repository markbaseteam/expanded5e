# Underwater Combat

When adventurers pursue [[Sahuagin]] back to their undersea homes, fight off sharks in an ancient shipwreck, or find themselves in a flooded dungeon room, they must fight in a challenging environment. Underwater the following rules apply.

When making a **melee weapon attack**, a creature that doesn't have a swimming speed (either natural or granted by magic) has disadvantage on the attack roll unless the weapon is a [[FearsD20 System/8. Combat/Weapons/Thrown Weapons/Dagger]], [[FearsD20 System/8. Combat/Weapons/Thrown Weapons/Javelin]], [[FearsD20 System/8. Combat/Weapons/Swords/Shortsword]], [[Spear]], or [[FearsD20 System/8. Combat/Weapons/Polearms/Trident]].

A **ranged weapon attack** automatically misses a target beyond the weapon's normal range. Even against a target within normal range, the attack roll has [[Disadvantage]] unless the weapon is a crossbow, a [[FearsD20 System/8. Combat/Weapons/Thrown Weapons/Net]], or a weapon that is thrown like a [[FearsD20 System/8. Combat/Weapons/Thrown Weapons/Javelin]] (including a spear, [[FearsD20 System/8. Combat/Weapons/Polearms/Trident]], or dart).

Creatures and objects that are fully immersed in water have [[Resistance]] to #fire damage.