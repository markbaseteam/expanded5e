# Opportunity Attacks

In a fight, everyone is constantly watching for a chance to strike an enemy who is fleeing or passing by. Such a strike is called an opportunity attack.

You can make an opportunity attack when a hostile creature that you can see moves out of your reach. To make the opportunity attack, you use your reaction to make one melee attack against the provoking creature. The attack occurs right before the creature leaves your reach.

You can avoid provoking an opportunity attack by taking the [[Disengage]] action. You also don't provoke an opportunity attack when you teleport or when someone or something moves you without using your movement, action, or reaction. For example, you don't provoke an opportunity attack if an explosion hurls you out of a foe's reach or if gravity causes you to fall past an enemy.

## Examples
- Standing up from [[Prone]]
- Drinking a potion
- Loading a crossbow
- Opening a door
- Picking a lock
- Using a complicated mechanism or puzzle
- Casting a spell that has both somatic and material components